/* Jessica Nguyen
 * CSS436, HW2
 * Weather.java
 * This class represents a de-serialized JSON object obtained by the GSON library for the Open Weather Map API
 */
public class Weather {
    String description;

    public Weather(String description) {
        this.description = description;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public String toString() {
        return description;
    }
}
