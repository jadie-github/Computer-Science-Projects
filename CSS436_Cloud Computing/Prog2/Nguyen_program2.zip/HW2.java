/* Jessica Nguyen
 * CSS436, HW2
 * HW2.java
 * This program takes as input the name of a
city and provides information about the weather for that city as well as one other interesting
fact
* APIS used:
*
 */

import java.net.*;
import java.io.*;
import java.util.*;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class HW2 {
    private static final String API_KEY = "03c8bd31a8cd6b1395c146da6ad2a64a";
    private static final int NUM_RETRIES = 3;
    private static final long WAIT_TIME = 1000;

    public static void main(String[] args) {
        if (args.length < 1) {
            System.out.println("Invalid number of parameters: Must enter a city name");
            return;
        }

        //clear all extra white spaces, put + between words to concatnate them in the URL
        String city ="";
        for(int i = 0; i < args.length; i++){
            city+=args[i] + "+";
        }
        city = city.trim().substring(0,city.length()-1);
        System.out.println("Input city is: " + city +"\n");

        API1(city);
        API2(city);
    }

    /* API1(): use the Open Weather Map API to look up weather info about an input city string
    Preconditions: String args is not null
    Postconditions: If API URL failed to load after NUM_RETRIES times, print error message
    */
    private static void API1(String args) {
        try {
            StringBuilder result = new StringBuilder();
            URL url = backOff("https://api.openweathermap.org/data/2.5/weather?q=" + args + "&appid=" + API_KEY);
            if(url == null){
                System.err.println("Open Weather Map API is unable to process the request.");
                return;
            }

            URLConnection conn = url.openConnection();
            BufferedReader rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String line;
            while ((line = rd.readLine()) != null) {
                result.append(line);
            }

            rd.close();
            //get json String
            String JSON = result.toString();

            //get JSON object
            JsonElement fileElement = JsonParser.parseString(JSON);
            JsonObject fileObject = fileElement.getAsJsonObject();

            //extract fields
            JsonArray weatherArray = fileObject.get("weather").getAsJsonArray();
            String description = "";
            JsonObject mainArray = fileObject.get("main").getAsJsonObject();
            double feels_like = mainArray.get("feels_like").getAsDouble();
            int pressure = mainArray.get("pressure").getAsInt();
            int humidity = mainArray.get("humidity").getAsInt();
            String name = fileObject.get("name").getAsString();
            Main main = new Main(feels_like, pressure, humidity);

            // if weatherArray is empty, return
            if (weatherArray.size() == 0) {
                System.out.println("Open Weather Map API: Could not find the city name");
                return;
            }

            for (JsonElement w : weatherArray) {
                JsonObject o = w.getAsJsonObject();

                description = o.get("description").getAsString();
                break; //get the first item only
            }
            Weather weather = new Weather(description);
            System.out.println("Open Weather Map API:\nThe weather for " + name + " is currently " + weather.toString() + ".\n" + main.toString() + "\n");

        } catch (IOException e) {
            System.err.println("ERROR: IOException");
        } catch (Exception e) {
            System.err.println("ERROR: Exception");
            e.printStackTrace();
        }
    }

    /* API2(): use the Teleport API to look up weather info about an input city string
    Preconditions: String args is not null
    Postconditions: If API URL failed to load after NUM_RETRIES times, print error message
    */
    private static void API2(String args) {
        try {
            StringBuilder result2 = new StringBuilder();
            URL url2 = backOff("https://api.teleport.org/api/cities/?search=" + args);
            if(url2 == null){
                System.err.println("Teleport API is unable to process the request.");
                return;
            }

            URLConnection conn2 = url2.openConnection();
            BufferedReader rd2 = new BufferedReader(new InputStreamReader(conn2.getInputStream()));
            String line2;
            while ((line2 = rd2.readLine()) != null) {
                result2.append(line2);
            }

            rd2.close();

            //get String
            String JSON2 = result2.toString();

            //get JSON element
            JsonElement fileElement2 = JsonParser.parseString(JSON2);
            JsonObject fileObject2 = fileElement2.getAsJsonObject();

            //extract fields
            JsonArray mainArray2 = fileObject2.get("_embedded").getAsJsonObject().get("city:search-results").getAsJsonArray();

            //if mainArray2 is empty, return
            if (mainArray2.size() == 0) {
                System.out.println("Teleport API: Could not find the city name");
                return;
            }

            String cityURL = "";
            for (JsonElement m : mainArray2) {
                JsonObject o = m.getAsJsonObject();

                JsonObject o1 = o.get("_links").getAsJsonObject();
                JsonObject o2 = o1.get("city:item").getAsJsonObject();
                cityURL = o2.get("href").getAsString();
                break; //get the first item only
            }

            StringBuilder result3 = new StringBuilder();
            URL url3 = backOff(cityURL);
            if(url3 == null){
                return;
            }

            URLConnection conn3 = url3.openConnection();
            BufferedReader rd3 = new BufferedReader(new InputStreamReader(conn3.getInputStream()));
            String line3;
            while ((line3 = rd3.readLine()) != null) {
                result3.append(line3);
            }

            rd3.close();

            //get JSON String
            String JSON3 = result3.toString();

            //get JSON element
            JsonElement fileElement3 = JsonParser.parseString(JSON3);
            JsonObject fileObject3 = fileElement3.getAsJsonObject();
            int population = fileObject3.get("population").getAsInt();
            String fullName = fileObject3.get("full_name").getAsString();
            System.out.println("Teleport API\nFun fact: the population in " + fullName + " is " + population + "!");

        } catch (IOException e) {
            System.err.println("ERROR: IOException");
        } catch (Exception e) {
            System.err.println("ERROR: Exception");
            e.printStackTrace();
        }
    }

    /* backOff(): performs exponential backoff algorithm. The wait time will be doubled every failed attempt, starting
                  with WAIT_TIME miliseconds
    Preconditions: String URL is not null
    Postconditions: prints error after NUM_RETRIES retries
    */
    private static URL backOff(String URL) throws Exception {
        int retries = NUM_RETRIES;
        long wait = WAIT_TIME;
        return retry(0, wait, URL);
    }

    /* retry(): recursively retries URL for NUM_RETRIES
    Preconditions: String URL is not null; int retries >= 0; long wait >= 0
    Postconditions: prints error after NUM_RETRIES retries
    */
    private static URL retry(int retries, long wait, String URL) throws Exception {
        if (retries > NUM_RETRIES) {
            System.err.println("Retry Failed for URL " + URL + ".\nTotal of attempts: " + (retries - 1) + ". Total wait time: "
                    + wait + "ms.");
            return null;
        }

        //puts thread to sleep for "wait" amount of miliseconds
        waitUntilNext(wait);

        //retry the link
        URL cur = new URL(URL);
        HttpURLConnection curr = (HttpURLConnection) cur.openConnection();
        curr.setRequestMethod("GET");
        int URLStatus = curr.getResponseCode();

        if (URLStatus >= 500) { //apply retry logic
            wait *= 2; //exponentially increase the amount of wait time every try
           return retry(retries + 1, wait, URL);
        } else if (URLStatus >= 400) {
            System.err.println("Client Server Error");
            return null;
        } else if (URLStatus >= 300) {//redirection
            System.out.println("Getting redirected URL...");
            return new URL(getFinalURL(curr));
        } else { //200 status OK
            return new URL(URL);
        }
    }

    /* waitUntilNext(): puts current thread to sleep for "wait" amount of miliseconds
    Preconditions: long wait >= 0
    Postconditions: thread will resume after sleeping;
                    throws InterruptedException if there was any errors during sleeping
    */
    private static void waitUntilNext(long wait){
        try {
            Thread.sleep(wait);
        } catch (InterruptedException e) {
            System.out.println("Error waiting until next try for the backoff strategy. Error: " + e.getMessage());
        }
    }

    /* getFinalURL(): returns redirected URL of input HttpURLConnection
     */
    public static String getFinalURL(HttpURLConnection url) {
        url.setInstanceFollowRedirects(false);
        try {
            url.connect();
            url.getInputStream();

        } catch (IOException e) {
            System.err.println("ERROR: Unable to get redirected URL");
        }
        return url.getHeaderField("Location");
    }
}

