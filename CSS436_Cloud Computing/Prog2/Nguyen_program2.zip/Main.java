/* Jessica Nguyen
 * CSS436, HW2
 * Main.java
 * This class represents a de-serialized JSON object obtained by the GSON library for the Open Weather Map API
 */
public class Main {
    double feelsLike;
    int pressure;
    int humidity;

    public Main(double feelsLike, int pressure, int humidity) {
        this.feelsLike = (int) (feelsLike - 273.15) * 9/5 + 32; //converts Kelvin to Farenheit
        this.pressure = pressure;
        this.humidity = humidity;
    }

    public double getFeelsLike() {
        return feelsLike;
    }

    public void setFeelsLike(double feelsLike) {
        this.feelsLike = feelsLike;
    }

    public int getPressure() {
        return pressure;
    }

    public void setPressure(int pressure) {
        this.pressure = pressure;
    }

    public int getHumidity() {
        return humidity;
    }

    public void setHumidity(int humidity) {
        this.humidity = humidity;
    }

    @Override
    public String toString() {
        return "It feels like " + feelsLike + " Farenheit.\n" +
                "The pressure is " + pressure + "hPa.\n" +
                "The humidity is " + humidity + "%.";
    }
}
