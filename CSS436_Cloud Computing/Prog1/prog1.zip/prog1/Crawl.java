/*
* Jessica Nguyen
* CSS 436, Prog 1
* This program downloads the html from the starting URI which is provided as the first
* argument to the program, the second argument is an int numHops. It will parse the html 
* finding the first <a href > reference to other
* absolute URIs. The application will then download the html from that page
* and repeat the operation. The program does this NumHops times.
*/

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.io.*; //for BufferedReader, IOException
import java.net.*; //for HttpURIConnection

public class Crawl {

	public static Set<String> visited = new HashSet<String>();

	/*
	 * Crawl(): Accepts a web URI, an int number of hops and return the URI and HTML
	 * of the website numHops from the original URI Precondition: User must input 2
	 * parameters as URI and int numHops Postcondition: Will return error if user
	 * failed to meet the input parameters Will return error if user enters in
	 * negative numHops Will return error if user enters in invalid URI
	 */
	public static void main(String[] args) {

		if (args.length < 2) {
			System.out.println("Invalid number of parameters");
			return;
		}

		int NumHops;
		try {
			NumHops = Integer.parseInt(args[1]);
		} catch(NumberFormatException e) {
			System.out.println("The second parameter must be a valid integer");
			return;
		}

		// verify int numHops
		if (NumHops < 0) {
			System.out.println("Invalid. Hopping amount must be positive.");
			return;
		}

		String cur = args[0];
		
//		
//		String cur = "http://googl.com";
//		int NumHops = 4;
		// verify URI
		try {
			if ((cur = verifyURI(cur)) == null) {
				System.out.println("Invalid Input Link.");
				return;
			}
		} catch (IOException e) {
			System.out.println("ERROR: IOException");
			return;
		} catch (URISyntaxException e) {
			System.out.println("ERROR: URISyntaxException");
			return;
		}

		cur = format(cur);
		String prev = cur;

		visited.add(cur);

		System.out.println("Original URL: " + cur + "\n");
		int currentHop = 1;
		while (currentHop <= NumHops) {
			
			// read the file
			// once find a link, check if it's in visited yet or not,
			// if yes, skip, if not, add, then set prev to cur, and cur to new URI
			// if can't find a link, break

			cur = getNextURI(prev);

			System.out.println("Currently in hop " + currentHop + "\nURL is " + cur);
			
			if (cur.equals(prev)) {
				System.out.println("The page does not contains anymore URLs");
				break;
			}

			prev = cur;
			currentHop++;
			System.out.println();
		}

		print(cur); // prints result

	}

	/*
	 * getNextURI(): returns the first URI that is contained in the HTML file of the
	 * input URI always return a valid link and will handle all links that are
	 * broken in the HTML Precondition: input URI is a valid http/https URI
	 * Postcondition: throws IOException if URI is invalid
	 */
	private static String getNextURI(String curURI) {

		URL cur;
		try {
			cur = new URL(curURI);

			// open HTML of curURI, read into buffer
			BufferedReader in = new BufferedReader(new InputStreamReader(cur.openStream()));
			String inputLine;
			StringBuffer content = new StringBuffer();
			while ((inputLine = in.readLine()) != null) // reading in all the lines from HTML
			{
				content.append(inputLine);
				content.append(System.lineSeparator());
			}

			String HTML = content.toString(); // convert StringBuffer to a String that contains all HTML of the current
												// page

			String patternToSearchFor = "<a(.*?)href=\"http(.*?)\""; // search for something in the form of <a ... href=" ... "

			Pattern p = Pattern.compile(patternToSearchFor, Pattern.CASE_INSENSITIVE);
			Matcher m = p.matcher(HTML);

			while (m.find()) {

				for (int i = 0; i <= m.groupCount(); i++) { // iterate through all hrefs found in matcher

					String newLink = m.group(i);
					
					int start = newLink.indexOf("\"http"); //start at the link after href="
					if (start == -1) {
						continue; // skip if the href is not http/https
					}
					start++;
					newLink = newLink.substring(start);

					int stop = newLink.indexOf("\"");

					newLink = newLink.substring(0, stop); // get the URI between quotation marks

					// if the link is valid, add that to the list of visited URIS
					if ((newLink = verifyURI(newLink)) != null) { // check for trailing slash "/", assumption that there can be multiple trailing slashes like uwb.edu///

						newLink = format(newLink);

						if (!visited.contains(newLink)) { // if we haven't visited that URI, add to the list of URIs
							visited.add(newLink);
							return newLink;
						} 
					}
				}

			}

			in.close();
		} catch (MalformedURLException e) {
			System.out.println("ERROR: MalformedURLException");
		} catch (IOException e) {
			System.out.println("ERROR: IOException");
		} 
			catch (URISyntaxException e) {
			System.out.println("ERROR: URISyntaxException");
		}
		return curURI;

	}

	private static String format(String newLink) {
		int end = newLink.length() - 1;
		while (end >= 0) {
			if (newLink.charAt(end) != '/') {
				break;
			}
			end--;
		}

		return newLink.substring(0, end + 1);// truncate off the end where there are trailing slashes
	}

	/*
	 * verifyURL(): check if the input URL is valid 
	 * Postcondition: throws IOException if URL is invalid 
	 * 				return null if URL returns status codes 4xx, 5xx 
	 * 				return valid URL if URL returns status code 2xx, 3xx (redirected URL)
	 */
	private static String verifyURI(String URI) throws IOException, URISyntaxException {

		URL cur = new URL(URI);
		HttpURLConnection curr = (HttpURLConnection) cur.openConnection();
		curr.setRequestMethod("GET");
		int URIStatus = curr.getResponseCode();

		if (URIStatus >= 500) {
			// retry 3 times
			int ct = 1;
			while (ct <= 3) {
				System.out.println("Internal Server Error. Trying again...");
				curr = (HttpURLConnection) cur.openConnection();
				curr.setRequestMethod("GET");
				URIStatus = curr.getResponseCode();
				if (URIStatus >= 200 && URIStatus < 300) { // if success
					break;
				}
				ct++;
			}
			System.out.println("Internal Server Error");
			return null;
		} else if (URIStatus >= 400) {
			System.out.println("Client Server Error");
			return null;
		} else if (URIStatus >= 300) {
			
			return getFinalURL(curr);
		}

		return URI;
	}

	/* getFinalURL(): returns redirected URL of input HttpURLConnection
	 */
	public static String getFinalURL(HttpURLConnection url) {

		url.setInstanceFollowRedirects(false);
		try {
			url.connect();
			url.getInputStream();

		} catch (IOException e) {
			System.out.println("ERROR: IOException");
		}
		return url.getHeaderField("Location");
	}
	

	/*
	 * print(): prints the final URI landed on after crawl numHops times, and output its HTML 
	 * Precondition: input URI is valid 
	 * Postcondition: throws IOException if URI is invalid
	 */
	private static void print(String URL) {
		System.out.println("Final URL is: " + URL);

		URI url;
		try {
			url = new URI(URL);

			URL cur = url.toURL();

			BufferedReader in = new BufferedReader(new InputStreamReader(cur.openStream()));
			String inputLine;
			StringBuffer content = new StringBuffer();
			while ((inputLine = in.readLine()) != null) // reading in all the lines
			{
				content.append(inputLine);
				content.append(System.lineSeparator());
			}
			System.out.println(content); // prints out HTML of the curURI
		} catch (IOException e) {
			System.out.println("ERROR: IOException");
		} catch (URISyntaxException e) {
			System.out.println("ERROR: URISyntaxException");
		} catch (IllegalArgumentException e) {
			System.out.println("ERROR: IllegalArgumentException");
		}
	}

}
