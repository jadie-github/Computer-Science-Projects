/*JESSICA NGUYEN
 * CSS 430, PROJECT 1J
 * This Shell.java program resembles a terminal shell on Mac, or linux shell on Windows that runs indefinitely.
 * Users will be able to pass in a list of terminal commands and execute
 * threads either sequentially (delimiter " ; ") or concurrently (delimiter " & " ); 
 * or calling exit if they want to exit out of the Shell program.
 * */

import java.util.*;
class Shell extends Thread {
	private Set<Integer> listOfChildThreads;
	
	/* Shell() -- constructor
	Postconditions: a Shell( ) object has been instantiated
    				listOfChildThreads is initiated to empty HashSet
	*/
    public Shell(){
        listOfChildThreads = new HashSet(); //hashset so it's easier to use the remove method
    }

    /* run() -- execution method
    Preconditions: listOfChildThreads is initiated as HashSet
    Postconditions: interprets user input commands and executes them as independent processes;
      				The behavior of the shell simply repeats until the user enters “exit”
    */
    public void run() {
    	for(int line = 1; ; line++) {
            String cmdLine ="";
            
            //takes in user input from keyboard
            do {
                StringBuffer input = new StringBuffer();
                SysLib.cerr("shell[" + line + "]% ");
                SysLib.cin(input);
                cmdLine = input.toString();


            } while (cmdLine.length() == 0);

            //converts user input from String to String[]
            String[] args = SysLib.stringToArgs(cmdLine);
            
            //keeps track of the start of every sub-command in input
            int first = 0;
                        
            //if user types "exit", exit program
            if(args.length == 1 && args[0].equals("exit")) {
                break;
             }

            //if input is blank or empty, skip this round of commands
             if(args.length < 1) {
                 continue;
             }
             
             //parse through the entire input command
            for(int i = 0 ; i < args.length; i++) {
            	//if we meet a delimiter or reached end of command
            	if(args[i].equals(";")|| args[i].equals("&") || i == args.length - 1) {
            		
            		//helper function to return arguments of the current sub-command to the left of the delimiter so far
            		String[] cmd = generate(args, first, (i == args.length - 1) ? i + 1 : i);
            		
            		if(cmd != null) {
            			
            			//spawns child process
            			int returnStatus = SysLib.exec(cmd);
            			
            			//if returnStatus of child process is not error
            			if(returnStatus != -1 ) {
            				//add to the total list of current child threads going on
            				listOfChildThreads.add(returnStatus);
            			} else {
            				first = i + 1;
            				continue; //can't be executed, just skip the line, for example user entered && or ;; or any other type of invalid commands
            				
            			}
            			
            			//if the delimiter is ; call join() repeatedly so we can wait until all child threads are finished
            			if(args[i].equals(";") || i == args.length - 1) { // need to call join
            				
            				//a flagger value to let us know whether to continue with this command or not in the case there's been an error
            				boolean isValid = true;
            				
            				//while there's still some child threads running in the background, keep calling join() to wait for them all to finish
            				while(!listOfChildThreads.isEmpty() && isValid) {
                				int childID = SysLib.join();
                				
                				//if error, set isValid to false so on next iteration, we don't run anymore
                				if(childID < 0) {
                					isValid = false;
                				}else {
                					
                					//if the list contains the childID, removes that childID since it's done processing
                					if(listOfChildThreads.contains(childID)) {
                				
                						listOfChildThreads.remove(childID);
                					}
                				}
                			}
            				
            				if(!isValid) {
            					break; //break out of the for loop
            				}
            			
            			}
            			
            		}
            		
            		//update first to be the next index for the next sub-command 
            		first = i + 1; //1
            			
            	}
            }
           
    	}
    	
    	//after breaking out of for loop, exit the program
    	SysLib.exit();
    }

    /* generate() -- private helper method
    Parameters: String [ ] args that stores the user input command
				int start represents the starting index of the current child process
				int end represents the ending index of the current child process
	Preconditions: String[ ] args is not null
				   int start >= 0 and < args.length
				   int end >= 0 and < args.length
 	Postconditions: returns null if start < end
	      			returns  a String[ ] that contains command for the subprocess in args starting at index start, ending at index end
    */ 
    private String[] generate(String[] args, int start, int end) {
    	//if see a delimiter, subtract end index by 1 so we don't include the delimiter when doing array copy
    	if (args[args.length - 1].equals(";") || args[args.length - 1].equals("&")) {
    		end--; 
        }
    	
    	//if invalid indexes, return null
    	if (end - start <= 0) {
            return null;
        } else {
        	//make a new  array for the arguments specified at indexes start --> end
            String[] ans = new String[end - start];
            
            int index =0; //keeps track of the index ans is at
            //copies the portion of args into ans from index start --> end
            for(int i = start; i < end; i++) {
                ans[index] = args[i];
                index++;
            }
            
            return ans;
        }
    }
}
    