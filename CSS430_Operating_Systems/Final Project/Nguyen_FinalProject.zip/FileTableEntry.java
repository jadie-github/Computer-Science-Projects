/*
 * Student: Audrey Nguyen & Jessica Nguyen
 * Instructor: Professor Parson
 * Assignment: Final Project
 * Description: Represents an entry within FileTable
 */

public class FileTableEntry {
	public int seekPtr; // a file seek pointer
	public final Inode iNode; // a reference to its iNode
	public final short iNumber; // this iNode number
	public int count; // # threads sharing this entry
	public final String mode; // "r", "w", "w+", or "a"

	// modes
	public static final String READONLY = "r"; // read only
	public static final String WRITEONLY = "w"; // write only
	public static final String READWRITE = "w+"; // read and write
	public static final String APPEND = "a"; // append

	// Constructor
	public FileTableEntry(Inode i, short inumber, String m) {
		seekPtr = 0; // the seek pointer is set to the file top
		iNode = i;
		iNumber = inumber;
		count = 1; // at least on thread is using this entry
		mode = getMode(m); // once access mode is set, it never changes
		iNode.count++; // update iNode count
		if (mode == APPEND) // if mode is append
			seekPtr = iNode.length; // seekPtr points to the end of file
	}

	// Retrieves the mode
	public static String getMode(String mode) {
		mode = mode.toLowerCase();
		if (mode.equals("r"))
			return READONLY;
		if (mode.equals("w"))
			return WRITEONLY;
		if (mode.equals("w+"))
			return READWRITE;
		if (mode.equals("a"))
			return APPEND;
		return null;
	}
}
