import java.util.Vector;

/*
 * Student: Audrey Nguyen & Jessica Nguyen
 * Instructor: Professor Parson
 * Assignment: Final Project
 * Description: Represents the file table
 * Contains all the entries stored within the file table
 */

public class FileTable {
	private Vector<FileTableEntry> table; // The table containing the entries
	private Directory dir; // The root directory

	// Constructor
	// instantiate a file (structure) table
	// creates a reference to the directory from the file system
	public FileTable(Directory directory) { 
		table = new Vector<FileTableEntry>(); 
		dir = directory; // 
	}

	// Allocates a file to the table with the name and mode passed in as strings
	public synchronized FileTableEntry falloc(String fname, String m) {
		String mode = FileTableEntry.getMode(m);
		short iNumber = -1;
		Inode iNode = null;
		FileTableEntry fte;
		
		// if mode is invalid, return null
		if (mode == null)
		{
			return null;
		}
		
		while (true) {
			// allocate/retrieve and register the corresponding inode using dir
			iNumber = fname.equals("/") ? 0 : dir.namei(fname);
			
			// if file does not exist
			if (iNumber < 0) { 
				// do not allocate file if read only
				if (mode == FileTableEntry.READONLY) 										
				{
					return null;
				}

				// return null if unable to allocate an iNumber for the file
				if ((iNumber = dir.ialloc(fname)) < 0)
				{
					return null; 
				}
					
				// allocate Inode with default constructors
				iNode = new Inode();
				break;
			}
			
			iNode = new Inode(iNumber);
			
			// no more to open
			if (iNode.flag == Inode.DELETE)
			{
				return null; 
			}
				
			if (iNode.flag == Inode.UNUSED || iNode.flag == Inode.USED)
			{
				break; // no need to wait for anything
			}
				
			// flags left include read and write
			// if mode is "r" 
			if (mode.equals(FileTableEntry.READONLY) && iNode.flag == Inode.READ)
			{
				break; // no need to wait on READ
			}	
			
			// if the flag is WRITE for "r", or READ or WRITE for "w" "w+" or
			// "a" we wait in all cases
			try {
				wait();
			} catch (InterruptedException e) {
			}
		}
		// increment this iNode's count
		iNode.count++;

		// immediately write back this iNode to the disk
		iNode.toDisk(iNumber);

		// allocate new file table entry for this file name
		fte = new FileTableEntry(iNode, iNumber, m);

		// add FTE to table
		table.add(fte);

		// return a reference to this FTE
		return fte;
	}

	// Frees the file table entry from the table
	public synchronized boolean ffree(FileTableEntry fte) {
		// if null, it's already free
		if (fte == null)
		{
			return true; 
		}

		Inode iNode = fte.iNode;
		short iNumber = fte.iNumber;

		// the FTE was not found in my table
		if (!table.removeElement(fte))
		{
			return false;			
		}

		// decrement this iNode's count
		if (iNode.count > 0)
		{
			iNode.count--;			
		}

		// when no more FTEs point to iNode, flag = 0
		if (iNode.count == 0)
		{
			iNode.flag = 0;
		}

		// save the corresponding iNode to the disk
		iNode.toDisk(iNumber);

		// notify waiting threads
		if (iNode.flag == Inode.READ || iNode.flag == Inode.WRITE)
		{
			notify();			
		}

		// free this FTE
		fte = null; // the FTE is now eligible for garbage collection

		// the FTE was found in my table
		return true;
	}

	// Check if table is empty
	public synchronized boolean fempty() {
		return table.isEmpty(); 
	}
}
