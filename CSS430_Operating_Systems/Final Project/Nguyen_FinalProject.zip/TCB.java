/*
 * Student: Audrey Nguyen & Jessica Nguyen
 * Instructor: Professor Parson
 * Assignment: Final Project
 * Description: Represents a thread control block
 */

public class TCB {
	private Thread thread = null;
	private int tid = 0;
	private int pid = 0;
	private boolean terminated = false;
	private int sleepTime = 0;

	// User file descriptor table
	// each entry pointing to a file (structure) table entry
	public FileTableEntry[] ftEnt = null;

	// Constructor
	public TCB(Thread newThread, int myTid, int parentTid) {
		thread = newThread;
		tid = myTid;
		pid = parentTid;
		terminated = false;

		ftEnt = new FileTableEntry[32];

		// making sure the array is empty and pointing to null
		for (int i = 0; i < 32; i++)
			ftEnt[i] = null;
		// fd[0], [1], [2] are kept null for input, output, err

		Kernel.report("a new thread (thread=" + thread + " tid=" + tid
				+ " pid=" + pid + ")");
	}

	// Returns the thread associated with the TCB
	public synchronized Thread getThread() {
		return thread;
	}

	// Returns thread id of the TCB
	public synchronized int getTid() {
		return tid;
	}

	// Returns the parent id of the TCB
	public synchronized int getPid() {
		return pid;
	}

	// Sets boolean representing if the TCB is terminated
	public synchronized boolean setTerminated() {
		return (terminated = true);
	}

	// Returns boolean representing if tje terminated
	public synchronized boolean getTerminated() {
		return terminated;
	}

	// Gets the file descriptor associated with the entry passed in
	public synchronized int getFd(FileTableEntry entry) {
		if (entry == null)
			return -1;
		for (int i = 3; i < 32; i++) {
			if (ftEnt[i] == null) {
				ftEnt[i] = entry;
				return i;
			}
		}
		return -1;
	}

	// Gets the file entry associated with the file descriptor passed in
	public synchronized FileTableEntry returnFd(int fd) {
		// check for requested entry
		if (fd < 3 || fd >= 32)
		{
			return null;
		}
			
		// if found, return the FTE and set pointer to null
		FileTableEntry oldEnt = ftEnt[fd];
		ftEnt[fd] = null;
		return oldEnt;
	}

	// Gets the FTE
	public synchronized FileTableEntry getFte(int fd) {
		return fd >= 3 && fd < 32 ? ftEnt[fd] : null;
	}
}
