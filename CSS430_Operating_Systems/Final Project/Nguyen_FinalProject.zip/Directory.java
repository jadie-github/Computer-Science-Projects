/*
 * Student: Audrey Nguyen & Jessica Nguyen
 * Instructor: Professor Parson
 * Assignment: Final Project
 * Description: Represents the root directory of the file system
 * The file system consists only of a single level directory
 */

public class Directory {
    private static int maxChars = 30; // max characters of each file name

    // Directory entries
    private int fsize[];        // each element stores a different file size.
    private char fnames[][];    // each element stores a different file name.

    // Constructor
    public Directory(int maxInumber) { // directory constructor

        fsize = new int[maxInumber];     // maxInumber = max files

        for (int i = 0; i < maxInumber; i++) {
            fsize[i] = 0;                 // all file size initialized to 0
        }

        fnames = new char[maxInumber][maxChars];

        String root = "/";                // entry(inode) 0 is "/"

        fsize[0] = root.length();        // fsize[0] is the size of "/".

        for (int i = 0; i < root.length(); i++) {
            fnames[0][i] = root.charAt(i);
        }

        root.getChars(0, fsize[0], fnames[0], 0); // fnames[0] includes "/"
    }

    // Used to initialize the Directory instance with a byte array read from the disk
    // assumes data[] received directory information from disk
    // initializes the Directory instance with this data[]
    // returns 0 if successful, -1 if there are errors
    public void bytes2directory(byte data[]) {
        int offset = 0;
        for (int i = 0; i < fsize.length; i++, offset += 4) {
            fsize[i] = SysLib.bytes2int(data, offset);
        }
        for (int i = 0; i < fnames.length; i++, offset += maxChars * 2) {
            String fname = new String(data, offset, maxChars * 2);
            fname.getChars(0, fsize[i], fnames[i], 0);
        }
    }

    // Used to convert the Directory instance into a byte array
    public byte[] directory2bytes() {
        // converts and return Directory information into a plain byte array
        // this byte array will be written back to disk
        // note: only meaningful directory information should be converted
        // into bytes.
        byte[] dir, toWrite;
        
        // create the byte array to return
        dir = new byte[fsize.length * 4 + fnames.length * maxChars * 2];
        int offset = 0;
        
        // convert the data in fsize[i] to bytes and write into dir byte array
        for (int i = 0; i < fsize.length; i++, offset += 4)
            SysLib.int2bytes(fsize[i], dir, offset);

        // get the file name of this file then convert the string into bytes
        for (int i = 0; i < fnames.length; i++, offset += maxChars * 2) {
            String fname = new String(fnames[i], 0, fsize[i]);
            toWrite = fname.getBytes();

            // write fname to dir array
            for (int j = 0; j < toWrite.length; j++) {
                dir[offset] = toWrite[j];
                offset++;
            }
        }
        return dir;
    }

    // Allocates a new inode number for a file to be created (filename)
    // Returns the new inode number if successful, returns -1 if unsuccessful
    public short ialloc(String fileName) {
        // Makes sure length of file name is within bounds
        for (int i = 1, l = fsize.length; i < l; i++) {
            if (fsize[i] == 0) {
                fsize[i] = Math.min(fileName.length(), maxChars);
                fileName.getChars(0, fsize[i], fnames[i], 0);
                return (short) i;
            }
        }

        // returns -1 if wasn't able to allocate a new inode
        return (short) -1;
    }

    // Deallocates this inumber (inode number) and delete the corresponding file
    public boolean ifree(int iNumber) {
        // checks if within bounds
        if ((iNumber >= 0) && (iNumber <= fsize.length)) {
            // checks if there is something allocated at the index
            if (fsize[iNumber] < 0) {
                return false;
            }
            fsize[iNumber] = 0;
            return true;
        }

        // returns false if wasn't able to delete the inode and file
        return false;
    }

    // Returns the inumber corresponding to this filename
    public short namei(String fileName) {
        // Makes sure length of file name is within a valid range (not to small or large)
        String fname;
        int length = fileName.length();
        
        // Iterates through fsize to look for the correct file
        for (int i = 0, l = fsize.length; i < l; i++) {
            if (fsize[i] == length) {
                fname = new String(fnames[i], 0, fsize[i]);
                if (fileName.compareTo(fname) == 0) {
                    return (short) i;
                }
            }
        }

        // returns -1 if wasn't able to find filename
        return -1;
    }
}
