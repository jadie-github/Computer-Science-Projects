/*Jessica Nguyen
CSS430, Program 1C
processes.cpp
This program imitates the behavior of the Linux shell when user enters "ps -A | grep ____ | wc -l" by using
OS concepts like fork, pipe, and wait. It creates 3 nested child-processes that executes one command at a time,
and redirect their input/output using dup2() to the appropriate child process in order to carry out the whole command line.
*/

#include <stdlib.h>     // for exit
#include <stdio.h>      // for perror
#include <unistd.h>     // for fork, pipe
#include <sys/wait.h>   // for wait
#include <iostream>     // for cerr, cout
using namespace std;

//main() -- driver
/* parameters: takes in a char array as user input where argv[0] is the program name, and argv[1] is the paramater for the program
                int argc is the count of how many elements there are in the argv array
    preconditions: argc == 2, argv has 2 elemements
    postconditions: program will run "ps -A | grep argv[1] | wc -l" as if you were to type it in the Linux command line
*/
int main(int argc, char *argv[]){
    enum {READ, WRITE};
    int FD1[2];
    int FD2[2];
    pid_t pid;

    if(argc != 2){ //if user enters in wrong amount of input
        perror("Invalid arguments."); 
        exit(EXIT_FAILURE);
    }

    pid = fork(); //child
    if(pid < 0){
        perror("Unable to fork.");
        exit(EXIT_FAILURE);
    }

    if(pipe(FD1) < 0){ //make a pipe out of File Descriptor 1
        perror("Unable to create pipe 1.");
        exit(EXIT_FAILURE);
    }

    if(pid == 0){
        pid = fork(); //grand child
        
        if(pid < 0){
            perror("Unable to fork.");
            exit(EXIT_FAILURE);
        }

        if(pipe(FD2) < 0){ //make a pipe out of File Descriptor 2
            perror("Unable to create pipe 2.");
            exit(EXIT_FAILURE);
        }

        if(pid == 0){
            pid = fork(); //great grand child
        
            if(pid < 0){
                perror("Unable to fork.");
                exit(EXIT_FAILURE);
            }

            if(pid == 0){  //great
                dup2(FD2[WRITE], 1); //this duplicates the file descriptor 2's write end to slot 1
                
                //this closes the ends of parent's pipe because right now we don't need to use that pipe
                // also closes the read end of current pipe so we can write data to it
                close(FD2[READ]);
                close(FD1[WRITE]);
                close(FD1[READ]);

                execlp("ps", "ps", "-A", NULL); //execute "ps -A" once we have all the pipes set up
                
            } else { 
                waitpid(pid, NULL, 0); //grandchild waits for great grandchild to be done

                //this allows for output from ps -A to go into input of grep ___
                dup2(FD2[READ], 0);
                dup2(FD1[WRITE], 1);

                //this closes the write end of current pipe and closes the read end of parent's pipe
                close(FD2[WRITE]);
                close(FD1[READ]);
                
                execlp("grep", "grep", argv[1], NULL); //executes grep ___

            }
        
        } else {
            
            waitpid(pid, NULL, 0); //child waits for grandchild to be done

            //duplicates read end of current parent pipe to slot 0
            dup2(FD1[READ], 0);

            //close the child and grandchild pipes and the write end of this current pipe
            close(FD1[WRITE]);
            close(FD2[WRITE]);
            close(FD2[READ]);

            execlp("wc", "wc", "-l", NULL);

        }
    } else {
        waitpid(pid, NULL, 0); //parent waits for everything to be done
    }

    exit(EXIT_SUCCESS);

    return 0;
}