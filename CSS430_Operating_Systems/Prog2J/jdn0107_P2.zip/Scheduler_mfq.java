/**
 * Jessica Nguyen
 * CSS 430, Project2J
 * Scheduler_mfq.java
 * This program emulates a multilevel feedback queue thread scheduling algorithm for the ThreadOS Scheduler. It will
 * execute threads for a specific quantum and threads are chosen and placed depending on their "priorities" -- aka
 * positions in the different queue levels.
 * */
import java.util.*; // Scheduler_mfq.java

public class Scheduler extends Thread {
    @SuppressWarnings({"unchecked", "rawtypes"})
    private Vector<TCB>[] queue = new Vector[3];
    private int timeSlice;
    private static final int DEFAULT_TIME_SLICE = 1000;

    // New data added to the original algorithm
    private boolean[] tids; // Indicate which ids have been used
    private static final int DEFAULT_MAX_THREADS = 10000;

    // A new feature added to the original algorithm
    // Allocate an ID array, each element indicating if that id has been used
    private int nextId = 0;

    public Scheduler() {
        timeSlice = DEFAULT_TIME_SLICE;
        initTid(DEFAULT_MAX_THREADS);
        for (int i = 0; i < 3; i++) queue[i] = new Vector<TCB>();
    }

    public Scheduler(int quantum) {
        timeSlice = quantum;
        initTid(DEFAULT_MAX_THREADS);
        for (int i = 0; i < 3; i++) queue[i] = new Vector<TCB>();
    }

    // A new feature added to the original algorithm
    // A constructor to receive the max number of threads to be spawned
    public Scheduler(int quantum, int maxThreads) {
        timeSlice = quantum;
        initTid(maxThreads);
        for (int i = 0; i < 3; i++) queue[i] = new Vector<TCB>();
    }

    private void initTid(int maxThreads) {
        tids = new boolean[maxThreads];
        for (int i = 0; i < maxThreads; i++)
            tids[i] = false;
    }

    // A new feature added to the original algorithm
    // Search an available thread ID and provide a new thread with this ID
    private int getNewTid() {
        for (int i = 0; i < tids.length; i++) {
            int tentative = (nextId + i) % tids.length;
            if (tids[tentative] == false) {
                tids[tentative] = true;
                nextId = (tentative + 1) % tids.length;
                return tentative;
            }
        }
        return -1;
    }

    // A new feature added to the original algorithm
    // Return the thread ID and set the corresponding tids element to be unused
    private boolean returnTid(int tid) {
        if (tid >= 0 && tid < tids.length && tids[tid] == true) {
            tids[tid] = false;
            return true;
        }
        return false;
    }

    // A new feature added to the original algorithm
    // Retrieve the current thread's TCB from the queue
    public TCB getMyTcb() {
        Thread myThread = Thread.currentThread(); // Get my thread object
        synchronized (queue) {
            for (int level = 0; level < 3; level++) {
                for (int i = 0; i < queue[level].size(); i++) {
                    TCB tcb = queue[level].elementAt(i);
                    Thread thread = tcb.getThread();
                    if (thread == myThread) // if this is my TCB, return it
                        return tcb;
                }
            }
        }
        return null;
    }

    // A new feature added to the original algorithm
    // Return the maximal number of threads to be spawned in the system
    public int getMaxThreads() {
        return tids.length;
    }


    private void schedulerSleep() {
        try {
            Thread.sleep(timeSlice / 2);
        } catch (InterruptedException e) {
        }
    }

    // A modified addThread of the original algorithm
    public TCB addThread(Thread t) {
        TCB parentTcb = getMyTcb(); // get my TCB and find my TID
        int pid = (parentTcb != null) ? parentTcb.getTid() : -1;
        int tid = getNewTid(); // get a new TID
        if (tid == -1)
            return null;
        TCB tcb = new TCB(t, tid, pid); // create a new TCB
        queue[0].add(tcb);
        return tcb;
    }

    // A new feature added to the original algorithm
    // Removing the TCB of a terminating thread
    public boolean deleteThread() {
        TCB tcb = getMyTcb();
        if (tcb != null) {
            this.interrupt();
            return tcb.setTerminated();
        } else
            return false;
    }

    public void sleepThread(int milliseconds) {
        try {
            sleep(milliseconds);
        } catch (InterruptedException e) {
        }
    }

    // run() - A modified run of the original algorithm
    /*  1. Each slice has a certain quantum (called "slice"), 0 get 1 (timeslice / 2), 1 get 2 (timeslice), 2 get 4 (timeslice * 2)
        2. A new thread is always inserted into queue 0
        3. Queue 0 - execute current thread, scheduler gets interrupted every half quantum then move onto next thread in line
           Move previous thread to Queue 1
        4. Queue 1 - execute current thread, scheduler gets interrupted every half quantum then check if queue 0 has any thread or not
           If yes, halt current thread and move to queue 0. Repeat step 3.
           If no, continue running for another half quantum.
           Move previous thread to Queue 2
        5. Queue 2 - execute current thread, scheduler gets interrupted every half quantum then check if queue 0 or 1 has any thread or not
           If yes in queue 0, halt current thread and move to queue 0. Repeat step 3.
           If yes in queue 1, halt current thread and move to queue 1. Repeat step 4.
           If no, continue running for another 3 half quantums, interrupting every half quantum.
           Move previous thread to back of Queue 2. (round robin style)
    * */
    public void run() {
        Thread current = null;
        TCB currentTCB = null;
        //slices to allocate timeslices to each queue
        int slice[] = new int[3];

        //Keeps track of previously ran TCB on each queue
        TCB prevTCB0 = null;
        TCB prevTCB1 = null;
        TCB prevTCB2 = null;


        for (int i = 0; i < 3; i++)
            slice[i] = 0; // slice = [0, 0, 0] for all queues

        while (true) {
            try {
                // get the next TCB and its thread from the highest queue
                int level = 0;
                for (; level < 3; level++) {
                    //check if there's already timeslices or not in slice[].
                    // if == 0 it means that there's no previousTCB in process, we can go ahead and pick the first TCB in queue
                    if (slice[level] == 0) {
                        if (queue[level].size() == 0) {
                            // check to make sure there's at least some TCB in this current queue to run
                            continue;
                        }
                        currentTCB = queue[level].firstElement();
                        break;
                    } else { //if there's already something running, don't take the first one, continue where we left off
                        if(level == 0){
                            currentTCB = prevTCB0;
                        } else if (level == 1){
                            currentTCB = prevTCB1;
                        } else {
                            currentTCB = prevTCB2;
                        }

                        break;
                    }
                }

                //reset if nothing in the queues
                if (level == 3)
                    continue;

                //check if the current TCB has finished or not.
                if (currentTCB.getTerminated() == true) {
                    // If yes, remove this thread from queue[level]
                    // Return this thread id
                    // slice[level] must be 0 --> reset the timeslice slots
                    slice[level] = 0;
                    queue[level].remove( currentTCB );
                    returnTid( currentTCB.getTid( ) ); //set current thread unused
                    continue;
                }

                // if TCB not finished, obtain thread
                current = currentTCB.getThread();

                if ((current != null)) {
                    // If current is alive, resume it otherwise start it.
                    if ( current.isAlive( ) ) {
                        current.resume();
                    }
                    else {
                        // Spawn must be controlled by Scheduler
                        // Scheduler must start a new thread
                        current.start( );
                    }
                }

                // Scheduler should sleep here. half a quantum
                // If current is alive, suspend it.
                schedulerSleep();
                // System.out.println("* * * Context Switch * * * ");

                synchronized ( queue[level] ) {
                    if (current != null && current.isAlive()) {
                        current.suspend();
                    }
                }

                //[1, 2, 4] for slices of half quantums, current thread is already suspended at this point
                // update the prevTCBs to whatever we've suspended at this point so we can come back to it later
                if(level == 0){
                    prevTCB0 = currentTCB;
                } else if (level == 1){
                    prevTCB1 = currentTCB;
                } else {
                    prevTCB2 = currentTCB;
                }

                // Update slice[level].
                // if slice[level] returns to 0,
                //   currentThread must go to the next level or
                //   rotate back in queue[2]
                slice[level]++;

                if(level == 0 && slice[level] >= 1) { //check if queue 0 has ran all of its alloted timeslices (1)
                    slice[level] = 0;
                    current.suspend();
                    queue[level].remove(currentTCB); // currentThread must go to the next level
                    queue[level + 1].add(currentTCB);
                    prevTCB0 = null; //reset the prevTCB if we decided to let it go and move it

                } else if (level == 1) {
                    if (slice[level] >= 2) { //check if queue 1 has ran all of its alloted timeslices (2)
                        slice[level] = 0;
                        current.suspend();
                        queue[level].remove(currentTCB); // currentThread must go to the next level
                        queue[level + 1].add(currentTCB);
                        prevTCB1 = null; //reset the prevTCB if we decided to let it go and move it

                    } else { //has slices left, keep running
                        if (queue[0].size() != 0){ // check if higher queues have anything or not, if so, break out
                            continue;
                        }
                    }

                } else if (level == 2){
                    if (slice[level] >= 4) { //check if queue 2 has ran all of its alloted timeslices (4)
                        slice[level] = 0;
                        current.suspend();
                        queue[level].remove(currentTCB); // currentThread must rotate back in queue[2]
                        queue[level].add(currentTCB);
                        prevTCB2 = null; //reset the prevTCB if we decided to let it go and move it
                    } else {
                        if (queue[0].size() != 0 || queue[1].size() != 0){
                            // check if higher queues have anything or not, if so, break out
                            continue;
                        }
                    }

                }
            } catch (NullPointerException e3) {
            }
            ;
        }
    }