import java.util.*;

/*Jessica Nguyen
 * CSS430, Project 4J
 * Cache.java
 * This program represents a Cache and a page table for mapping logical memory to physical memory.
 * Users will be able to read a file to buffer, write a file from buffer to memory, sync all files to be saved to disk,
 * and wipes all cached blocks.
 * */

public class Cache {

	/*---PRIVATE CLASS ENTRY---*/

	private class Entry {
		int frameNumber;
		boolean reference;
		boolean dirty;
		
		public Entry() {
			this.frameNumber = -1;
			this.reference = false;
			this.dirty = false;
		}
	}

	/*---PRIVATE CLASS FIELDS---*/
	//an array of Entry's called pageTable
	private Entry[] pageTable;
	//a vector of byte arrays that acts as the cache
	private Vector<byte[]> cache;
	//a field that holds the block Size for the cache
	private int blockSize;
	//int to keep track of current victim
	private int victim;

	/* constructor
	 * postconditions:  allocates a cacheBlocks number of cache blocks in memory.
	 * Each cache Block should contain a blockSize-byte of data.
	 */
	public Cache(int blockSize, int cacheBlocks) {
		
		this.pageTable = new Entry[cacheBlocks];
		this.cache = new Vector<>();
		this.blockSize = blockSize;
		this.victim = 0;

		for (int i = 0; i < pageTable.length; i++) {
			cache.add(new byte[blockSize]);
			pageTable[i] = new Entry();
		}
		
	}

	// findFreePage() -- finds and returns index of a free page in pageTable
	private int findFreePage() {
    	for(int i = 0 ; i < pageTable.length; i++) {
    		if(pageTable[i].frameNumber == -1) {
    			return i;
    		}
    	}
        return -1;
    }

	/* read() -- reads into the buffer[ ] the contents of the cache block specified by blockId
	 * preconditions: blockId >= 0, buffer is initiated to a valid byte array
	 * postconditions: returns false if blockId < 0
	 * 					returns true if succesfully reads contents of cache to buffer
	 * */
	public synchronized boolean read(int blockId, byte buffer[]) {
		if (blockId < 0) {
			return false;
		}

		//go through the pageTable to look for block in memory
		for (int i = 0; i < pageTable.length; i++) {
			//if found corresponding block
			if (pageTable[i].frameNumber == blockId) {
				//copy array from cache.elementAt(i) to buffer
				byte[] newArray = cache.elementAt(i);
				System.arraycopy(newArray, 0, buffer, 0, blockSize);

				//set the reference bit
				pageTable[i].reference = true;
				return true;
			}
			
		}

		/*---SWAPPING STARTS---*/

		//if unable to find a matching block in memory, find a free page
		int next = findFreePage();
		
		//if there are no free page, finds a victim using enhanced 2nd chance algorithm
		if(next == -1) {
			next = nextVictim();
		}
		
		//if that victim's dirty bit is true (meaning it hadn't been deep copied into the disk yet),
		// call writeBack() to free this element
		if(pageTable[next].dirty) {
			writeBack(next);
		}
		
		//read the corresponding disk block from disk into this freed element
		//byte[] from cache or buffer?
		SysLib.rawread(blockId, buffer);

		//copies contents of buffer to new array and set its contents to correct position in cache
		byte[] newArray = new byte[blockSize];
		System.arraycopy(buffer, 0, newArray, 0, blockSize);
		cache.set(next, newArray);

		//update this element's frame# with this input blockId set the reference bit
		pageTable[next].frameNumber = blockId;
		pageTable[next].reference = true;

        return true;
	}

	/* write() -- Writes the contents of buffer[ ] array to the cache block specified by blockId
	 * preconditions: blockId >= 0, buffer is initiated to a valid byte array
	 * postconditions: returns false if blockId < 0
	 * 					returns true if succesfully writes contents to cache
	 * */
	public synchronized boolean write(int blockId, byte buffer[]) {
		if (blockId < 0) {
			return false;
		}

		//go through the pageTable to look for block in memory
		for (int i = 0; i < pageTable.length; i++) {
			//if found corresponding block
			if (pageTable[i].frameNumber == blockId) {
				byte[] newArray = new byte[blockSize];
				System.arraycopy(buffer, 0, newArray, 0, blockSize);

				// Writes the contents of new buffer array to the block specified by blockId
				cache.set(i, newArray);
				
				//set the reference and dirty bit
				pageTable[i].reference = true; 
				pageTable[i].dirty = true;
				return true;
			}
			
		}

		/*---SWAPPING STARTS---*/

		//if unable to find a matching block in memory, find a free page
		int next = findFreePage();
		
		//if there are no free page, finds a victim using enhanced 2nd chance algorithm
		if(next == -1) {
			next = nextVictim();
		}
		
		//if that victim's dirty bit is true (meaning it hadn't been deep copied into the disk yet),
		// call writeBack() to free the element
		if(pageTable[next].dirty) {
			writeBack(next);
		}
		
		//write the corresponding disk block from disk into this freed element
		SysLib.rawwrite(blockId, buffer);

		//copies contents of buffer to new array and set its contents to correct position in cache
		byte[] newArray = new byte[blockSize];
		System.arraycopy(buffer, 0, newArray, 0, blockSize);
		cache.set(next, newArray);

		//update this element's frame# with this input blockId, set the reference and dirty bit
		pageTable[next].frameNumber = blockId;
        pageTable[next].reference = true;
        pageTable[next].dirty = true;
        
        return true;
		
	}

	/*	nextVictim() -- performs enhanced 2nd chance algorithm
		postconditions: returns the index for the next victim that will be selected from the enhanced 2nd chance algorithm
	*/
	private int nextVictim()
	{

		//lets you know if you found a (0,0) pair or not on the first run through
		boolean firstRound = false;
		//lets you know if you've got passed round 1 to the second round or not
		boolean secondRound = false;
		int circle = victim; // Place marker to indicate full rotation.

		while (true)
		{
			victim = (victim + 1) % pageTable.length; //increment victim by 1, round robin

			//if we found a (0,0) pair, or if we're on the second round and found a (0,1) pair
			if (!pageTable[victim].reference && (!pageTable[victim].dirty || secondRound)) {
				return victim;
			}

			if (victim == circle)   // If we've completed a cycle around the cache,
			{
				if (secondRound) firstRound = true; // If we finished second round, now we can set off to find a (0,1) pair
				secondRound = !secondRound;       // After the second round, reset the bit to start finding (0,0) pairs again
			}

			//if we couldn't find a (0,1) pair, start setting every bypassed ref bit to 0
			if (firstRound) pageTable[victim].reference = false;
		}
	}

	/* writeBack() -- writes virtual memory from pageTable to physical memory on the disk
	 * preconditions: victimEntry >= 0
	 * postconditions: Writes back all dirty blocks to Disk
	 */
	private void writeBack(int victimEntry) {
		if(victimEntry < 0){
			return;
		}

		if(pageTable[victimEntry].frameNumber != -1 && pageTable[victimEntry].dirty) {
			byte[] newArray = cache.elementAt(victimEntry);
			SysLib.rawwrite(pageTable[victimEntry].frameNumber, newArray);
			//rawread takes in an int frameNumber, a byte[] array, then reads data from a pageTable block(at index frameNumber) to the byte[] array 
		
			pageTable[victimEntry].dirty = false;
			//after we saved all data to hard disk, we can reset the dirty bit, meaning it is reset to be unmodified from this point
		}
	}

	// sync() -- Writes back all dirty blocks to Disk
	public synchronized void sync() {
		for (int i = 0; i < pageTable.length; i++) {
			if (pageTable[i].dirty) {
				// write pageTable[i] to disk
				// Forces Disk to write back all contents to the DISK file
				writeBack(i);
			}
			SysLib.sync();
		}
	}

	// flush() -- Writes back all dirty blocks to Disk and wipes all cached blocks
	public synchronized void flush() {
		// reset the pageTable
		for (int i = 0; i < pageTable.length; i++) {
			if (pageTable[i].dirty) {
				// write pageTable[i] to disk
				// Forces Disk to write back all contents to the DISK file
				writeBack(i);
			}
			
			pageTable[i].frameNumber = -1;
			pageTable[i].reference = false;
		}
		
		SysLib.sync();
	}
}
