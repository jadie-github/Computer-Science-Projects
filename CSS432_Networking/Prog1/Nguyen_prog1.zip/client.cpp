/* Jessica Nguyen
CSS 432, Program 1
client.cpp
This program receives six arguments and interact with server.cpp to perform
data transfers, each based on type such as 1: multiple writes, 2: writev, or 3: single write
using threads and sockets established between the two programs.
*/
#include <pthread.h> // pthread
#include <iostream>
#include <sys/types.h>   // socket, bind
#include <sys/socket.h>  // socket, bind, listen, inet_ntoa
#include <netinet/in.h>  // htonl, htons, inet_ntoa
#include <arpa/inet.h>   // inet_ntoa
#include <netdb.h>       // gethostbyname
#include <unistd.h>      // read, write, close
#include <strings.h>     // bzero
#include <netinet/tcp.h> // SO_REUSEADDR
#include <sys/uio.h>     // writev
#include <sys/time.h>    //gettimeofday
#include <stdio.h>

using namespace std;

const unsigned int BUF_SIZE = 1500;

/*main()
Preconditions: user must pass in 6 parameters for port, repetition, nbufs, bufsize, serverIp, and type
               port must be >= >= 1024 and <= 65536
               Repetitions must be >= 0
               nbufs * bufsize must equal 1500
               Type of transfer must be either 1, 2, or 3
Postconditions: creates a socket connection to a listening server program, 
                sends a data buffer to the server and calculates then output 
                data sending time, roundtrip times, and number of reads done by server
*/
int main(int argc, char *argv[])
{
    //verify number of arguments
    if (argc != 7) //a.out counts as 1 param so the rest add up to 6 more
    {
        cerr << "Error: Must pass in 6 parameters: port, repetition, nbufs, bufsize, serverIp, type" << endl;
        return -1;
    }

    //verify port number
    if ((atoi(argv[1]) < 1023) || (atoi(argv[1]) > 65536))
    {
        std::cerr << "Error: Port number must be >= 1024 and <= 65536" << std::endl;
        return -1;
    }

    // verify repetitions
    if (atoi(argv[2]) < 0)
    {
        cerr << "Error: Repetitions must be >= 0" << endl;
        return -1;
    }
    //verify nbufs and bufsize product
    if ((atoi(argv[3]) * atoi(argv[4])) != BUF_SIZE)
    {
        cerr << "Error: nbufs * bufsize must equal 1500" << endl;
        return -1;
    }

    //verify type of transfer
    if (atoi(argv[6]) > 3 || atoi(argv[6]) < 1)
    {
        cerr << "Error: Type of transfer must be either 1, 2, or 3 only" << endl;
        return -1;
    }

    //at this point, every parameter is valid

    //set up all parameters
    int server_port = atoi(argv[1]);
    int repetition = atoi(argv[2]);
    int nbufs = atoi(argv[3]);
    int bufsize = atoi(argv[4]);
    char *serverIp = argv[5];
    int type = atoi(argv[6]);

    //obtain host
    struct hostent *host = gethostbyname(serverIp); //testing use 127.0.0.1
    if (host == nullptr)
    {
        cerr << "Error: Failed to get host with given serverIp" << endl;
        return -1;
    }

    //set up socket connection
    sockaddr_in sendSockAddr;
    bzero((char *)&sendSockAddr, sizeof(sendSockAddr));                                         // zero out the data structure
    sendSockAddr.sin_family = AF_INET;                                                          // using IP
    sendSockAddr.sin_addr.s_addr = inet_addr(inet_ntoa(*(struct in_addr *)*host->h_addr_list)); // sets the address to the address we looked up
    sendSockAddr.sin_port = htons(server_port);                                                 // set the port to connect to

    //open & connect stream-oriented socket with internet address family
    int clientSd = socket(AF_INET, SOCK_STREAM, 0);
    if (clientSd < 0)
    {
        cerr << "Error: Failed to establish socket" << endl;
        close(clientSd);
        return -1;
    }
    //connect to server
    int connectStatus = connect(clientSd, (sockaddr *)&sendSockAddr, sizeof(sendSockAddr));
    if (connectStatus < 0)
    {
        cerr << "Error: Failed to connect to the server" << endl;
        close(clientSd);
        return -1;
    }

    // allocate data buffer for transfer
    char databuf[nbufs][bufsize]; //where nbufs * bufsize = 1500

    struct timeval start;
    struct timeval lap;
    struct timeval stop;
    long data_sending_time;
    long round_trip_time;

    //start the timer
    gettimeofday(&start, nullptr);
    
    for (int i = 0; i < repetition; i++)
    {
        if (type == 1)
        { //multiple writes using write()
            for (int j = 0; j < nbufs; j++)
            {
                write(clientSd, databuf[j], bufsize); //write each databuf my row
            }
        }

        else if (type == 2)
        { //write all at once using writev()
            struct iovec vector[nbufs];
            for (int j = 0; j < nbufs; j++)
            {
                vector[j].iov_base = databuf[j];
                vector[j].iov_len = bufsize;
            }

            writev(clientSd, vector, nbufs);
        }

        else
        { //single write
            write(clientSd, databuf, nbufs * bufsize);
        }
    }
    
    //record data transfer finish time
    gettimeofday(&lap, nullptr);
    data_sending_time = ((lap.tv_sec - start.tv_sec) * 1000000) + (lap.tv_usec - start.tv_usec); //calculate sending time

    //receive from the server an integer acknowledgement that shows how many ties the server called read()
    int bytesRead = 0;

    while(true){
        int numBytes = read(clientSd, &bytesRead, sizeof(bytesRead)); //not sure, why in server.cpp is buf but in here is byte read
  
        if(numBytes == -1){
            cerr << "Error: Unable to read bytes" <<endl;
            return -1;
        } else if(numBytes == 0){ //when numbytes = 0, means finished reading, so break out
            break;
        }
    }
    
    //record stop time
    gettimeofday(&stop, nullptr);
    round_trip_time = ((stop.tv_sec - start.tv_sec) * 1000000) + (stop.tv_usec - start.tv_usec); //calculate round trip time

    //output results
    cout << "Test " << type << ": data-sending time = " << data_sending_time << " usec, round-trip time = " << round_trip_time << " usec, #reads = " << bytesRead << endl;

    //close socket, exit
    close(clientSd);
    return 0;
}

//creates a signal handler to take cleanup actions after user use ctrl-c to exit the program
void signal_handler_callback(int signum)
{
    cout << "Caught signal " << signum << endl;
    exit(signum);
}
