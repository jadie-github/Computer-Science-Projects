/* Jessica Nguyen
CSS 432, Program 1
server.cpp
Server.cpp: This program receives two arguments and interact with client.cpp to listen
to incoming client connections, create new threads, read and write data from the buffer,
then send the number of reads back to the client side.
*/

#include <pthread.h> // pthread
#include <iostream>
#include <sys/types.h>   // socket, bind
#include <sys/socket.h>  // socket, bind, listen, inet_ntoa
#include <netinet/in.h>  // htonl, htons, inet_ntoa
#include <arpa/inet.h>   // inet_ntoa
#include <netdb.h>       // gethostbyname
#include <unistd.h>      // read, write, close
#include <strings.h>     // bzero
#include <netinet/tcp.h> // SO_REUSEADDR
#include <sys/uio.h>     // writev
#include <sys/time.h>    //gettimeofday
#include <stdio.h>
#include <errno.h>
#include <fcntl.h>

const unsigned int BUF_SIZE = 1500;

//this struct contains the socket number and repetitions for passing parameters through pthread function
struct threadData{
    int sd;
    int reps;
};

void *execute(void *data_struct);

/* main()
Preconditions: user must pass in 2 parameters for port number and repetitions.
               Values must be >= 0
Postconditions: accepts any incoming connections through socket, creates a new thread,
 and writes back received data to the calling client program                
*/
int main(int argc, char *argv[])
{
    //verify number of arguments
    if (argc != 3) //a.out counts as 1 param so the rest add up to 2 more
    {
        std::cerr << "Error: Must pass in 2 parameters: port and repetition" << std::endl;
        return -1;
    }

    //verify port number
    if ((atoi(argv[1]) < 1023) || (atoi(argv[1]) > 65536))
    {
        std::cerr << "Error: Port number must be >= 1024 and <= 65536" << std::endl;
        return -1;
    }

    // verify repetitions
    if (atoi(argv[2]) < 0)
    {
        std::cerr << "Error: Repetitions must be >= 0" << std::endl;
        return -1;
    }

    //at this point, every parameter is valid

    //set up all parameters
    int server_port = atoi(argv[1]);
    int repetition = atoi(argv[2]);

    //set up socket connection
    sockaddr_in acceptSockAddr;
    bzero((char *)&acceptSockAddr, sizeof(acceptSockAddr)); // zero out the data structure
    acceptSockAddr.sin_family = AF_INET;                    // using IP
    acceptSockAddr.sin_addr.s_addr = htonl(INADDR_ANY);     // listen on any address this computer has
    acceptSockAddr.sin_port = htons(server_port);           // set the port to listen on

    //open & connect stream-oriented socket with internet address family
    int serverSd = socket(AF_INET, SOCK_STREAM, 0); // creates a new socket for IP using TCP
    if (serverSd < 0)
    {
        std::cerr << "Error: Failed to establish socket" << std::endl;
        close(serverSd);
        return -1;
    }

    //set SO_REUSEADDR option -- release server port as soon as your server process is terminated
    const int on = 1;
    setsockopt(serverSd, SOL_SOCKET, SO_REUSEADDR, (char *)&on, sizeof(int)); // this lets us reuse the socket without waiting for hte OS to recycle it

    // Bind the socket
    int bindResult = bind(serverSd, (sockaddr *)&acceptSockAddr, sizeof(acceptSockAddr)); // bind the socket using the parameters we set earlier
    if (bindResult < 0)
    {
        std::cout << "Error: Failed to bind the socket" << std::endl;
        close(serverSd);
        return -1;
    }

    // Listen on the socket
    int n = 5;                              //connection request size
    int listenResult = listen(serverSd, n); // listen on the socket and allow up to n connections to wait.
    if (listenResult != 0)
    {
        std::cerr << "Error: Unable to listen on the socket";
        return -1;
    }

    sockaddr_in newsockAddr; // place to store parameters for the new connection
    socklen_t newsockSize = sizeof(newsockAddr);

    //loop back to the accept command and wait for a new connection
    while (1)
    {
        // Accept the connection as a new socket
        int newSd = accept(serverSd, (sockaddr *)&newsockAddr, &newsockSize); // grabs the new connection and assigns it a temporary socket
        if (newSd == -1)
        {
            std::cout << "Error: Unable to connect to client. Trying again";
            return -1;
        }
        //create a new thread
        pthread_t thread;
        std::cout << "Creating a new thread..." << std::endl;
        struct threadData data;
        data.sd = newSd;
        data.reps = repetition;
        //call execute() by the new thread, pass in parameter newSd
        int newThread = pthread_create(&thread, nullptr, execute, (void *)&data);
        if (newThread != 0)
        {
            std::cout << "Error: Unable to create thread";
            return -1;
        }

        //when done, merge threads back to main program
        pthread_join(thread, nullptr);
    }

    return 0;
}

/* execute()
Preconditions: accepts a data_struct that contains newSd and repeition numbers
Postconditions: write back received data to the calling client program and output the total time to console
*/
void *execute(void *data_struct)
{
    struct threadData *data;
    data = (struct threadData *) data_struct;
    int socket = data->sd;
    int repetition = data->reps;

    //allocate databuf
    char *databuf[BUF_SIZE];

    struct timeval start;
    struct timeval stop;
    long data_receiving_time;
    int count = 0;

    //start the timer
    gettimeofday(&start, nullptr);

    //repeat reading data from the client into databuf
    for (int i = 0; i < repetition; i++)
    {

        //use read() to receive data from client with newSd
        for (int nRead = 0; (nRead += read(socket, databuf, BUF_SIZE - nRead)) < BUF_SIZE; ++count);
       //++count;
    }

    //send the number of read() calls made as an acknowledgement, use write() to send back data to client with newSd
    write(socket, &count, sizeof(count));

    //stop the timer
    gettimeofday(&stop, nullptr);

    //calculate total time
    data_receiving_time = (stop.tv_sec - start.tv_sec) * 1000000 + (stop.tv_usec - start.tv_usec);

    //print out statistics
    std::cout << "data-receiving time = " << data_receiving_time << " usec" << std::endl;
    //close socket
    close(socket);
    return 0;
}

//creates a signal handler to take cleanup actions after user use ctrl-c to exit the program
void signal_handler_callback(int signum)
{
    std::cout << "Caught signal " << signum << std::endl;
    exit(signum);
}
