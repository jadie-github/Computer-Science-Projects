/* Jessica Nguyen
CSS 432, Program 2
retriever.cpp
retriever.cpp: This program exercise a simplified version of HTTP.  
The retriever will work in conjunction with any web server to retrieve 
a specified file name by user from that web server. It uses HTTP 1.1 to
send and received HTTP GET requests
*/
#include <iostream>
#include <cstring>
#include <fstream>
#include <pthread.h>     // pthread
#include <sys/types.h>   // socket, bind
#include <sys/socket.h>  // socket, bind, listen, inet_ntoa
#include <netinet/in.h>  // htonl, htons, inet_ntoa
#include <arpa/inet.h>   // inet_ntoa
#include <netdb.h>       // gethostbyname
#include <unistd.h>      // read, write, close
#include <strings.h>     // bzero
#include <netinet/tcp.h> // SO_REUSEADDR
#include <sys/uio.h>     // writev
#include <sys/time.h>    //gettimeofday
#include <stdio.h>
#include <signal.h>

using namespace std;

// const string output_file = "output.txt"; //contains the file retrieved from the GET request
const std::string ERR_404 = "HTTP/1.1 404 Not Found\r\n";
const std::string ERR_401 = "HTTP/1.1 401 Unauthorized\r\n";
const std::string ERR_403 = "HTTP/1.1 403 Forbidden\r\n";
const std::string ERR_400 = "HTTP/1.1 400 Bad Request\r\n";

string readEachLine(int socketInfo);
void signal_callback_handler(int signum);

/*main()
Preconditions: user must pass in 2 parameters for host name and file name
Postconditions: creates a socket connection to a listening server program, 
                sends a HTTP GET request to the server and retrieves the file content,
                then finally saves the file content to "output.txt"
*/
int main(int argc, char *argv[])
{
    if (argc != 3)
    {
        cerr << "Error: Must pass in 2 parameters: server address and file" << endl;
        return -1;
    }

    signal(SIGINT, signal_callback_handler);

    int port;
    string serv = argv[1];
    int index = serv.find(":");
    if (index != string::npos)
    {
        port = stoi(serv.substr(index + 1, serv.length() - index - 1)); //extract the port number
        serv = serv.substr(0, index);
    }
    else
    {
        port = 6543; //use my port if no ports are detected
    }
    const char *serverAddress = serv.c_str();
    const char *fileName = argv[2];

    //obtain host
    struct hostent *host = gethostbyname(serverAddress); //testing use 127.0.0.1
    if (host == nullptr)
    {
        cerr << "Error: " << ERR_400 << "Failed to get host with given server name: " << string(serverAddress) << endl;
        return -1;
    }

    //set up socket connection
    sockaddr_in sendSockAddr;
    bzero((char *)&sendSockAddr, sizeof(sendSockAddr));                                         // zero out the data structure
    sendSockAddr.sin_family = AF_INET;                                                          // using IP
    sendSockAddr.sin_addr.s_addr = inet_addr(inet_ntoa(*(struct in_addr *)*host->h_addr_list)); // sets the address to the address we looked up
    sendSockAddr.sin_port = htons(port);                                                        // set the port to connect to
    cout << "Connecting to port: " << port << endl;
    //open & connect stream-oriented socket with internet address family
    int clientSd = socket(AF_INET, SOCK_STREAM, 0);
    if (clientSd < 0)
    {

        cerr << gai_strerror(clientSd) << "\n"
             << "Error: Failed to establish socket" << endl;
        close(clientSd);
        return -1;
    }

    //connect to server
    int connectStatus = connect(clientSd, (sockaddr *)&sendSockAddr, sizeof(sendSockAddr));
    if (connectStatus < 0)
    {
        cerr << gai_strerror(connectStatus) << "\n"
             << "Error: Failed to connect to the server" << endl;
        close(clientSd);
        return -1;
    }

    cout << "Host: " << serverAddress << endl;
    cout << "File name: " << fileName << endl;

    //get request
    string request = "";
    if (string(fileName) == "malformed.html")
    {
        request += "GOT /";
    }
    else
    {
        request += "GET /";
    }
    request += string(fileName) + " HTTP/1.1\r\n" +
               "Host: " + string(serverAddress) + "\r\n";
    request += "Accept: text/html,application/xhtml+xml,application/xml,*/*\r\n";
    request += "Connection: keep-alive\r\n\r\n";

    cout << "\nRequest: \n"
         << request << endl;
    int sendResult = send(clientSd, request.c_str(), strlen(request.c_str()), 0);
    // Couldn't send the request.
    if (sendResult <= 0)
    {
        cerr << gai_strerror(sendResult) << "\n"
             << "Unable to send the request" << endl;
        return -1;
    }

    cout << "Response:" << endl;
    int len = 0;
    bool foundContentLength = false;
    while (1)
    {
        string responseHeader = readEachLine(clientSd);
        // cout << "ReponseHeader=" << responseHeader << endl;
        if (responseHeader == "")
        {
            if (!foundContentLength)
            {
                cout << "couldn't find length so setting it to 2000" << endl;
                len = 2000; //max len if no length specified in http response
            }
            break;
        } //end of header
        cout << responseHeader << endl;
        if (responseHeader.substr(0, 15) == "Content-Length:")
        {
            len = atoi(responseHeader.substr(16, responseHeader.length()).c_str());
            foundContentLength = true;
        } // Bytes in message
    }

    ofstream outputFile;
    string output_file = string(fileName);
    int idx = output_file.find(".");
    if (idx != string::npos)
    {
        output_file = output_file.substr(0, idx);
    }
    idx = output_file.find("/");
    while (idx != string::npos)
    {
        output_file = output_file.substr(0, idx) + "_" + output_file.substr(idx + 1, output_file.length() - idx - 1);
        //dont allow slashes to be in the file name because the system would misunderstand that as creating a subfolder instead
        idx = output_file.find("/");
    }

    output_file = string(serverAddress) + "_" + output_file + ".txt";

    char buffer[len]; // Allocate a buffer to store the content

    int read = recv(clientSd, &buffer, sizeof(buffer), 0);

    buffer[read] = '\0';
    string outputText = "\nRetrieved Contents:\n";
    for (int i = 0; i < sizeof(buffer); i++)
    {
        outputText += buffer[i];
    }
    cout << outputText << endl;

    if ((outputText.find(ERR_400) != string::npos) ||
        (outputText.find(ERR_401) != string::npos) ||
        (outputText.find(ERR_403) != string::npos) ||
        (outputText.find(ERR_404) != string::npos)) //returned error, won't save
    {
        cout << "Retrieve error: unable to save file" << endl;
    }
    else
    {

        //if all is fine, save into text file
        outputFile.open(output_file);
        cout << sizeof(buffer) << endl;
        for (int i = 0; i < sizeof(buffer); i++)
        {
            outputFile << buffer[i];
        }

        outputFile.close();
        cout << "Contents of " << string(fileName) << " saved in file \"" + output_file << "\"" << endl;
    }
    cout << "--------------------------------------------------------------" << endl;

    close(clientSd);

    return 0;
}

/*  readEachLine() -- parse the header info received from the request
    Postconditions: returns a string containing a single line from the return HTTP header, ends with \r\n 
                    if reached end of HTTP header, returns empty string
*/
string readEachLine(int clientSd)
{
    string line = "";
    char prev = 0;
    while (true)
    {
        char cur = 0;
        recv(clientSd, &cur, 1, 0);
        
        if (cur == '\n' || cur == '\r')
        {
            if (prev == '\r' && cur == '\n')
            { //stop and return line when you see a \r\n
                break;
            }
        }
        else
        {
            line += cur;
        }
        prev = cur;
    }
    return line;//+'\0';
}

void signal_callback_handler(int signum)
{
    cout << "Caught signal " << signum << endl;
    // Terminate program
    exit(signum);
}