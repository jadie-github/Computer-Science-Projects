#! /bin/sh
g++ -o server server.cpp -pthread -std=c++14
g++ -o retriever retriever.cpp -std=c++14

./server & 

# Test 1: Retriever accesses real server
./retriever example.com:80 index.html 

# Test 2: Retriever accesses valid file from my server
./retriever 127.0.0.1 index.html

# Test 3: Retriever accesses an unauthorized file from my server 
./retriever 127.0.0.1 SecretFile.html

# # Test 4: Retriever accesses a forbidden file from my server 
./retriever 127.0.0.1 forbidden.html

# # Test 5: Retriever requests access to a non-existent file from my server
./retriever 127.0.0.1 nonExistent.html

# # Test 6: Retriever sends a malformed request
./retriever 127.0.0.1 malformed.html
