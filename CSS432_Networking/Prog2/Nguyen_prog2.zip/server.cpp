/* Jessica Nguyen
CSS 432, Program 2
server.cpp
Server.cpp: This program works in conjunction with any web browser
to receive incoming HTTP GET requests, process the file requested,
and send back to the retriever the content of the requested file.
It uses HTTP 1.1 to send and received HTTP GET requests */

#include <pthread.h> // pthread
#include <iostream>
#include <sys/types.h>   // socket, bind
#include <sys/socket.h>  // socket, bind, listen, inet_ntoa
#include <netinet/in.h>  // htonl, htons, inet_ntoa
#include <arpa/inet.h>   // inet_ntoa
#include <netdb.h>       // gethostbyname
#include <unistd.h>      // read, write, close
#include <strings.h>     // bzero
#include <netinet/tcp.h> // SO_REUSEADDR
#include <sys/uio.h>     // writev
#include <sys/time.h>    //gettimeofday
#include <stdio.h>
#include <errno.h>
#include <fcntl.h>
#include <string>
#include <signal.h>

// using namespace std;
const std::string CODE_200 = "HTTP/1.1 200 OK\r\n";
const std::string ERR_404 = "HTTP/1.1 404 Not Found\r\n";
const std::string ERR_401 = "HTTP/1.1 401 Unauthorized\r\n";
const std::string ERR_403 = "HTTP/1.1 403 Forbidden\r\n";
const std::string ERR_400 = "HTTP/1.1 400 Bad Request\r\n";
const unsigned int BUF_SIZE = 1500;

//this struct contains the socket number and repetitions for passing parameters through pthread function
void *execute(void *data_struct);
void signal_callback_handler(int signum);
struct threadData
{
    int sd;
};

/* main()
Postconditions: accepts any incoming connections through socket, creates a new thread,
 and writes back received data to the calling retriever program                
*/
int main(int argc, char *argv[])
{
    signal(SIGINT, signal_callback_handler);
    //set up socket connection
    sockaddr_in acceptSockAddr;
    bzero((char *)&acceptSockAddr, sizeof(acceptSockAddr)); // zero out the data structure
    acceptSockAddr.sin_family = AF_INET;                    // using IP
    acceptSockAddr.sin_addr.s_addr = htonl(INADDR_ANY);     // listen on any address this computer has

    acceptSockAddr.sin_port = htons(6543); // set the port to connect to

    //open & connect stream-oriented socket with internet address family
    int serverSd = socket(AF_INET, SOCK_STREAM, 0); // creates a new socket for IP using TCP
    if (serverSd < 0)
    {
        std::cerr << gai_strerror(serverSd) << "\n"
                  << "Error: Failed to establish socket" << std::endl;
        close(serverSd);
        return -1;
    }

    //set SO_REUSEADDR option -- release server port as soon as your server process is terminated
    const int on = 1;
    setsockopt(serverSd, SOL_SOCKET, SO_REUSEADDR, (char *)&on, sizeof(int)); // this lets us reuse the socket without waiting for hte OS to recycle it

    // Bind the socket
    int bindResult = bind(serverSd, (sockaddr *)&acceptSockAddr, sizeof(acceptSockAddr)); // bind the socket using the parameters we set earlier
    if (bindResult < 0)
    {
        std::cerr << gai_strerror(bindResult) << "\n"
                  << "Error: Failed to bind the socket" << std::endl;
        close(serverSd);
        return -1;
    }

    // Listen on the socket
    int n = 5;                              //connection request size
    int listenResult = listen(serverSd, n); // listen on the socket and allow up to n connections to wait.
    if (listenResult != 0)
    {
        std::cerr << gai_strerror(listenResult) << "\n"
                  << "Error: Unable to listen on the socket" << std::endl;
        return -1;
    }

    sockaddr_in newsockAddr; // place to store parameters for the new connection
    socklen_t newsockSize = sizeof(newsockAddr);

    //loop back to the accept command and wait for a new connection
    int newSd;
    while (1)
    {
        // Accept the connection as a new socket
        newSd = accept(serverSd, (sockaddr *)&newsockAddr, &newsockSize); // grabs the new connection and assigns it a temporary socket

        if (newSd == -1)
        {
            std::cerr << gai_strerror(newSd) << "\n"
                      << "Error: Unable to connect to client." << std::endl;
            close(newSd);
            return -1;
        }
        //create a new thread
        pthread_t thread;
        std::cout << "Creating a new thread..." << std::endl;

        pthread_t new_thread;

        struct threadData data;
        data.sd = newSd;
        int newThread = pthread_create(&thread, nullptr, execute, (void *)&data);
        if (newThread != 0)
        {
            std::cerr << gai_strerror(newThread) << "\n"
                      << "Error: Unable to create thread" << std::endl;
            return -1;
        }

        //when done, merge threads back to main program
        pthread_join(thread, nullptr);
    }
    close(newSd);
    close(serverSd);
    return 0;
}

/*  getBody() -- prepares what the response should be for the GET response thrown from the client side
    Postconditions: fileContent will contain the return results of the HTTP call.
                    if the HTTP GET request was successful, fileContent contains CODE_200;
                    otherwise, fileContent contains the appropriate ERR message
*/
void getBody(std::string &filePath, bool done, std::string &statusCode, std::string &fileContent)
{
    //filepath format right now is /filename.ext

    if (done)
    { //if the request was formatted correctly and we received a header back

        if (filePath.substr(1, 2) == ".." || filePath == "/forbidden.html")
        {
            statusCode = fileContent = ERR_403; //trying to access parent folder -- forbidden
        }
        else if (filePath == "/SecretFile.html") //trying to access secret file
        {
            statusCode = fileContent = ERR_401; //unauthorized
        } else if(filePath == "/malformed.html"){
            statusCode = fileContent = ERR_400; //malformed request
        }
        else //request processed through
        {
            filePath = "." + filePath; //the file path will look something like: "./filename"

            FILE *file = fopen(filePath.c_str(), "r"); //search recursively until find the file

            if (file == nullptr)
            {
                std::cout << "Unable to open the file for reading" << std::endl;
                if (errno == EACCES)
                {
                    statusCode = fileContent = ERR_401; //access issues
                }
                else
                {
                    statusCode = fileContent = ERR_404; //not found
                }
            }
            else
            { // return code 200 OK
                //opening and read file into content
                std::cout << "Found file: " << filePath << std::endl;
                while (!feof(file))
                {
                    std::string line;
                    char c = fgetc(file);
                    if (c < 0)
                    {
                        continue; //do not accept non-ascii characters
                    }
                    fileContent += c;
                }
                fclose(file);
                statusCode = CODE_200;
            }
        }
    }
    else
    {
        // did not return appropriate headers response
        statusCode = fileContent = ERR_400;
    }
}

/*  readEachLine() -- parse the header info received from the request
    Postconditions: returns a string containing a single line from the return HTTP header, ends with \r\n 
                    if reached end of HTTP header, returns empty string
*/
std::string readEachLine(int clientSd)
{
    std::string line = "";
    char prev = 0;
    while (true)
    {
        char cur = 0;
        recv(clientSd, &cur, 1, 0);
        if (cur == '\n' || cur == '\r')
        {
            if (prev == '\r' && cur == '\n')
            { //stop and return line when you see a \r\n
                break;
            }
        }
        else
        {
            line += cur;
        }
        prev = cur;
    }
    return line;
}

/* execute()
Preconditions: accepts a data_struct that contains newSd
Postconditions: write back received data to the calling client program and output the HTTP Response to terminal
*/
void *execute(void *data_struct)
{
    struct threadData *data;
    data = (struct threadData *)data_struct;
    int clientSd = data->sd;
    bool done = false;
    std::string filePath = "";

    while (true)
    {
        std::string line = readEachLine(clientSd);
        if (line.empty()) //no more lines
        {
            break;
        }

        if (line.substr(0, 3) == "GET")
        {
            filePath = line.substr(4, line.length() - 13);
            //13 is length of " HTTP/1.1\r\n", we want to start at index 4 (after "GET ") until before the HTTP part to obtain the file path

            done = true;
            break;
        }
    }

    //send the return HTTP Response to retriever
    std::string statusCode = "";
    std::string fileContent = "";
    getBody(filePath, done, statusCode, fileContent);
    std::string length = std::to_string(fileContent.size());

    std::string body = statusCode + "Content-Length: " + length + "\r\nContent-Type: text/plain\r\n\r\n" + fileContent;
    send(clientSd, &body[0], body.size(), 0); //send back to client side

    close(clientSd);

    return 0;
}

void signal_callback_handler(int signum)
{
    std::cout << "Caught signal " << signum << std::endl;
    // Terminate program
    exit(signum);
}