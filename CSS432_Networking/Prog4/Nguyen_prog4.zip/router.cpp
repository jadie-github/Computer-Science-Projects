/* Jessica Nguyen
CSS 432, Program 4
router.cpp
This class represents a network router with functions: forwarding an ipv6 packet; print the current router table;
print IP address of a packet; and looking up their corresponding interfaces
*/
#include "router.h"
#include <bitset>
//constructor
Router::Router()
{
    this->table = new RouterTable();
    //start off with 4 interfaces
    // Route 1: c0a8:0:0:0:0:0:0:0:0/14
    this->table->addEntry(RouterTable::RouterTableEntry(bitset<128>("11000000101010000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000"), 14, "1"));

    // Route 2: c0a8:0400:0:0:0:0:0:0:0/24
    this->table->addEntry(RouterTable::RouterTableEntry(bitset<128>("11000000101010000000010000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000"), 24, "2"));

    // Route 3: c0a8:0200:0:0:0:0:0:0/24
    this->table->addEntry(RouterTable::RouterTableEntry(bitset<128>("11000000101010000000001000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000"), 24, "3"));

    // Route 4: c0a8:0200:0:0:0:0:0:0:0/26
    this->table->addEntry(RouterTable::RouterTableEntry(bitset<128>("11000000101010000000001000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000"), 26, "4"));
}

//reads the necessary header information for the respective packet type
//and looks up what output port to send the packet out on and returns that value
void Router::routeIPPacket(Router::ipv6 packet)
{

    if (packet.hopLim == 0)
    {
        cout << "Packet from IP " << RouterTable::printIP(packet.destAddr.to_string()) << " was Dropped due to Hop Limit expiration" << endl;
        return;
    }

    packet.hopLim--; //decrease hopLim
    RouterTable::RouterTableEntry ans = this->table->lookup(packet.destAddr);
    cout << "Packet with destination IP " << RouterTable::printIP(packet.destAddr.to_string()) << " was routed on " << RouterTable::printIP(ans.destinationIP.to_string()) << ", subnet mask = " << ans.subnetMask << ", " << ans.interface << endl;
    cout << "Binary representation: \nOutgoing packet IP:\t" << packet.destAddr.to_string() << endl;
    cout << "Interface IP:\t\t" << ans.destinationIP << endl;
    cout << "------------------------------------------------------------" << endl;
}

/*printRouterTable() -- prints every entry in the router table in terms of their IP address, subnet mask, and interface number
    */
void Router::printRouterTable()
{
    cout << "Current Router Table: \n"
         << *this->table << endl;
}

/*operator<<() -- prints IP address of input packet
*/
ostream &operator<<(ostream &os, const Router::ipv6 &packet)
{

    os << RouterTable::printIP(packet.destAddr.to_string());
    return os;
}
