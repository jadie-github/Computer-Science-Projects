/* Jessica Nguyen
CSS 432, Program 4
SwitchTable.h
This class represents an internal Switch Table with the following functions: add a new entry into the table;
print MAC address of an entry; look up to see if an entry exists in the table;
and get all the current entries in the table
*/

#include <iostream>
#include <list>
#include <bitset>
using namespace std;
class SwitchTable
{
    friend class Switch; //lets Switch class use methods from this class

public:
    //struct representing a single table entry
    struct SwitchTableEntry
    {
        // MAC address
        bitset<48> MACaddr; //colon heximal notation
        string interface;
        //constructor switchingTableEntry
        SwitchTableEntry(bitset<48> mac, string inf) : MACaddr(mac), interface(inf) {}
    };

    //constructor for SwitchTable
    SwitchTable() {}

    /*addEntry() -- adds a new entry into the current table; if the MAC address already exists, disregard the entry
    */
    void addEntry(SwitchTableEntry entry)
    {
        for (SwitchTableEntry e : this->getRoutes())
        {
            if (e.MACaddr == entry.MACaddr)
            {
                return; //don't allow dupes
            }
        }
        routes.push_back(move(entry));
    }

    //printMAC() -- represents MAC address in colon heximal notation
    string static printMAC(string input)
    {
        if (input.length() != 48)
        {
            cout << "Illegal binary sequence for MAC address. Try again" << endl;
            return "";
        }
        string currentStr = "";
        string ans = "";

        for (int i = 0; i < input.length(); i++)
        {
            currentStr += input.at(i);

            if ((i + 1) % 4 == 0)
            {
                int num = stoi(currentStr);
                int dec_val = 0, hex_val = 0;
                int base = 1;
                int tmp = num;

                //convert binary -> decimal
                while (tmp)
                { //while still divisible by 10
                    int last = tmp % 10;
                    tmp /= 10; //cut off last digit
                    dec_val += last * base;
                    base *= 2;
                }

                //convert values more than 10 to hex form
                if (dec_val > 9)
                {
                    ans += ('a' + static_cast<char>(dec_val - 10));
                }
                else
                {
                    ans += std::to_string(dec_val);
                }
                if (i != 0 && ((i + 1) % 16 == 0))
                {
                    ans += ":";
                } //every 16 bits, print a colon to conform with MAC styling syntax

                currentStr = ""; //reset current string to get next 4 bits
            }
        }
        ans = ans.substr(0, ans.length() - 1); //cut off last ":"
        return ans;
    }

    /*lookup() -- finds and returns the entry with the matching input MAC address
    */
    SwitchTableEntry lookup(bitset<48> target)
    {
        for (SwitchTableEntry e : routes)
        {
            if (e.MACaddr == target)
            {
                return e;
            }
        }

        return SwitchTableEntry(bitset<48>(), "not found");
    }

    //getRoutes() -- returns a list of existing table entries
    list<SwitchTableEntry> getRoutes()
    {
        return routes;
    }

private:
    list<SwitchTableEntry> routes;

    //operator<<() -- prints all entries in the switch table, including Source MAC address, and interface number
    friend ostream &operator<<(ostream &os, const SwitchTable &table)
    {
        if (table.routes.size() == 0)
        {
            os << "Switch Table is empty" << endl;
        }
        else
        {
            os << "Source MAC Address\tInterface" << endl;
            for (SwitchTableEntry e : table.routes)
            {
                os << e;
            }
        }
        return os;
    }

    //prints MAC address of input table entry
    friend ostream &operator<<(ostream &os, const SwitchTableEntry &route)
    {

        os << SwitchTable::printMAC(route.MACaddr.to_string());
        // Print interface
        os << "\t\t" << route.interface << endl;
        return os;
    }
};