/* Jessica Nguyen
CSS 432, Program 4
router.h
This class represents a network router with functions: forwarding an ipv6 packet; print the current router table;
print IP address of a packet; and looking up their corresponding interfaces
*/
#include <iostream>
#include <bitset>
#include "RouterTable.h"
using namespace std;
class Router
{

public:
    struct ipv6
    {
        bitset<4> version;      // 4 bits - Version
        bitset<8> trafficClass; // 8 bits - Traffic class
        bitset<20> flowLabel;   // 20 bits - Flow label
        bitset<16> payloadLen;  // 16 bits - Payload
        bitset<8> nextHdr;      // 8 bits - Next hdr
        int hopLim;             //  8 bits - Hop limit
        bitset<128> sourceAddr; // 128 bits - Src addr
        bitset<128> destAddr;   // 128 bits - Destination
        void *payload;

        ipv6()
        {
            version = bitset<4>("0110");
            trafficClass = bitset<8>("011011001");
            flowLabel = bitset<20>("01100110011001100110");
            payloadLen = bitset<16>("0110011001100110");
            nextHdr = bitset<8>("011011001");
            hopLim = 4;
            payload = static_cast<void *>(new std::string("this is a router message!"));
        }
        bitset<128> retrieveSourceIPAddress()
        {
            return this->sourceAddr;
        }
    };
    //constructor for Router
    Router();

    //reads the necessary header information for the respective packet type
    //and looks up what output port to send the packet out on and returns that value
    void routeIPPacket(ipv6 packet);

    /*printRouterTable() -- prints every entry in the router table in terms of their IP address, subnet mask, and interface number
    */
    void printRouterTable();

private:
    //every router has its own routing table
    RouterTable *table;
    friend ostream &operator<<(ostream &os, const ipv6 &packet);
};