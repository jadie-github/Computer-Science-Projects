/* Jessica Nguyen
CSS 432, Program 4
main.cpp
This program will (1) simulate receiving an ipv6 packet, processing it, looking up the output interface in the router table, and forwarding it,
(2) simulate forwarding an ethernet packet to a switch and self-learns the address of every packet as they pass through the switch table
*/

#include "router.h"
#include "switch.h"
#include <bitset>
#include <iostream>

using namespace std;

//forward declarations
void routerTest();
void switchTest();

int main(int argc, char *argv[])
{
    routerTest();
    cout << "\n\n===============================================================\n\n"
         << endl;
    switchTest();
}

void routerTest()
{
    cout << "This is router test for longest match algorithm" << endl;
    Router r; //calls default constructor
    r.printRouterTable();

    Router::ipv6 packet;
    packet.sourceAddr = bitset<128>(0x3617136200000000);

    // 192.168.2.254, should match with interface 3
    cout << "Test 1:" << endl;
    packet.destAddr = bitset<128>("11000000101010000000001011111110000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000");
    r.routeIPPacket(packet);

    // c0a8:3fff:e000:0:0:0:0:0, should match with interface 1
    cout << "Test 2:" << endl;
    packet.destAddr = bitset<128>("11000000101010000011111111111111111000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000");
    r.routeIPPacket(packet);

    // c0a8:04f0:0:0:0:0:0:0, should match with interface 2
    cout << "Test 3:" << endl;
    packet.destAddr = bitset<128>("11000000101010000000010011110000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000");
    r.routeIPPacket(packet);

    // c0a8:023f:c000:0:0:0:0:0, should match with interface 4
    cout << "Test 4:" << endl;
    packet.destAddr = bitset<128>("11000000101010000000001000111111110000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000");
    r.routeIPPacket(packet);

    // does not match with any entries, should default to 0:0:0:0:0:0:0:0/0
    cout << "Test 5:" << endl;
    packet.destAddr = bitset<128>(0x010203AA);
    r.routeIPPacket(packet);

    // simulate packet drop, should print out drop statement
    cout << "Test 6:" << endl;
    packet.hopLim = 0;
    r.routeIPPacket(packet);

    cout << "Finished Router Test" << endl;
}

void switchTest()
{
    cout << "This is switch test for self-learn algorithm" << endl;
    Switch s;
    s.printSwitchTable();

    Switch::ethernetFrame frame;
    /*  frames and their abbreviations:
        A: 0xFFFFFFFFFFFF
        B: 0x80818202837F
        C: 0x010103040506
        D: 0xABCDEFABCDEF
        E: 0x050403020100
    */
    
    // New entry, interface 1; broadcast to every interface
    // A to D: table records A's MAC
    cout << "Test 1:" << endl;
    frame.sourceAddr = bitset<48>(0xFFFFFFFFFFFF);
    frame.destAddr = bitset<48>(0xABCDEFABCDEF);
    s.forwardEthernetFrame(frame);
    s.printSwitchTable();

    // New entry, interface 2; broadcast to every interface
    // B to D: table records B's MAC
    cout << "Test 2:" << endl;
    frame.sourceAddr = bitset<48>(0x80818202837F);
    frame.destAddr = bitset<48>(0xABCDEFABCDEF);
    s.forwardEthernetFrame(frame);
    s.printSwitchTable();

    // New entry, interface 3; 
    // C to A: routes directly to A, table records C's MAC
    cout << "Test 3:" << endl;
    frame.sourceAddr = bitset<48>(0x010103040506);
    frame.destAddr = bitset<48>(0xFFFFFFFFFFFF);
    s.forwardEthernetFrame(frame);
    s.printSwitchTable();

    //D to B: records D's addr
    cout << "Test 4:" << endl;
    frame.sourceAddr = bitset<48>(0xABCDEFABCDEF);
    frame.destAddr = bitset<48>(0x80818202837F);
    s.forwardEthernetFrame(frame);
    s.printSwitchTable();

    // A to D again: this time should route directly to D
    cout << "Test 5:" << endl;
    frame.sourceAddr = bitset<48>(0xFFFFFFFFFFFF);
    frame.destAddr = bitset<48>(0xABCDEFABCDEF);
    s.forwardEthernetFrame(frame);
    s.printSwitchTable();

    // Route C to C: input interface matches output interface; should drop
    cout << "Test 6:" << endl;
    frame.sourceAddr = bitset<48>(0x010103040506);
    frame.destAddr = bitset<48>(0x010103040506);
    s.forwardEthernetFrame(frame);
    s.printSwitchTable();

    cout << "Finished Switch Test" << endl;
}