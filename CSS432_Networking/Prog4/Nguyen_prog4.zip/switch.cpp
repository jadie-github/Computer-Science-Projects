/* Jessica Nguyen
CSS 432, Program 4
switch.cpp
This class represents a network switch with functions: forwarding an ethernet frame; print the current switch table;
print MAC address of a frame; and looking up their corresponding interfaces
*/
#include "switch.h"
#include <bitset>
//constructor for switch
Switch::Switch()
{
    this->switchTable = new SwitchTable(); //start off with no routes saved yet
}

//obtainInterface() -- returns the next interface available to assign to a new incoming ethernet frame, default to 0 for the first frame received
string Switch::obtainInterface()
{
    int max = 0;
    for (SwitchTable::SwitchTableEntry e : this->switchTable->getRoutes())
    {
        int cur = std::stoi(e.interface);
        if (cur > max)
        {
            max = cur;
        }
    }

    return std::to_string(max + 1); //1 more than biggest interface
}

/* forwardEthernetFrame() -- performs the processing and forwarding of a single ethernet frame
selflearns the incoming frame's MAC address as it receives new frames
while simultaneously add them into the switch table
*/
void Switch::forwardEthernetFrame(Switch::ethernetFrame input)
{
    if (input.sourceAddr == input.destAddr)
    {
        cout << "Output interface matches input interface. Discarding frame MAC " << SwitchTable::printMAC(input.sourceAddr.to_string()) << endl;
        return;
    }
    //check if the entry is already recorded previously in the switch table
    SwitchTable::SwitchTableEntry output = this->switchTable->lookup(input.destAddr);

    if (output.interface == "not found")
    {
        //if not found any matches
        cout << "No switching table entry found for frame " << input << endl;
        for (SwitchTable::SwitchTableEntry e : this->switchTable->getRoutes())
        {

            //broadcast to all interfaces
            cout << "Frame from MAC address " << input << " will be broadcasted to MAC address " << SwitchTable::printMAC(e.MACaddr.to_string()) << " on interface " << e.interface << endl;
        }
    }

    else
    {
        //if an entry is found
        cout << "Found matching entry! Frame from MAC " << input << " to MAC " << SwitchTable::printMAC(output.MACaddr.to_string()) << " was switched onto interface " << output.interface << endl;
    }

    //makes and adds new entry into Switch table
    switchTable->addEntry(SwitchTable::SwitchTableEntry(input.sourceAddr, obtainInterface()));
}

/*printSwitchTable() -- prints every entry in the switch table in terms of their MAC address and interface number
*/
void Switch::printSwitchTable()
{
    cout << "Current Switch Table: \n"
         << *this->switchTable << endl;
    cout << "------------------------------------------------------------" << endl;
}

/*operator<<() -- prints MAC address of input ethernet frame f
*/
ostream &operator<<(ostream &os, const Switch::ethernetFrame &f)
{
    os << SwitchTable::printMAC(f.sourceAddr.to_string());

    return os;
}