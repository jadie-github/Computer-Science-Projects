/* Jessica Nguyen
CSS 432, Program 4
RouterTable.h
This class represents an internal Router Table with the following functions: add a new entry into the table;
print IP address of an entry; look up to see if an entry exists in the table;
and get all the current entries in the table
*/

#include <iostream>
#include <list>
#include <bitset>
using namespace std;
class RouterTable
{
public:
    struct RouterTableEntry
    {
        bitset<128> destinationIP; // IP address
        int subnetMask;            //partitioning the organization's network into subnets
        string interface;

        //constructor for routingTableEntry
        RouterTableEntry(bitset<128> dest, int mask, string inf) : destinationIP(dest), subnetMask(mask), interface(inf) {}
    };
    
    //constructor for routingTable
    RouterTable() {}

    /*lookup() -- finds and returns the entry with the matching input IP address based on longest match algorithm;
                    will return 0:0:0:0/0 if no matching entries found
    */
    RouterTableEntry lookup(bitset<128> address) const
    {
        RouterTableEntry answer(bitset<128>(0x0000000), 0, "default interface");
        int longestMatch = -1;

        for (RouterTableEntry e : routes)
        {
            bool notAMatch = false;

            for (int i = 0; i < e.subnetMask; i++)
            {
                if (address.to_string().at(i) != e.destinationIP.to_string().at(i))
                {
                    notAMatch = true;
                    break;
                }
            }

            if (notAMatch)
            {

                continue;
            }
            else
            {
                //found
                answer = e;
                longestMatch = e.subnetMask; //update longest match
            }
        }

        if (longestMatch == -1)
        {
            //still didnt find
            cout << "No match found, routing to default interface 0" << endl;
        }

        return answer;
    }

    /*addEntry() -- adds a new entry into the current table; if the MAC address already exists, disregard the entry
    */
    void addEntry(RouterTableEntry entry)
    {
        routes.push_back(move(entry));
    }

    //printMAC() -- represents IP address in colon heximal notation
    string static printIP(string binary)
    {
        if (binary.length() != 128)
        {
            cout << "Illegal binary sequence. Try again" << endl;
            return "";
        }
        string currentStr = "";
        string ans = "";
        for (int i = 0; i < binary.length(); i++)
        {
            currentStr += binary.at(i);
            // cout << binary << endl;
            if ((i + 1) % 4 == 0)
            {
                int num = stoi(currentStr);
                int dec_val = 0, hex_val = 0;
                int base = 1;
                int tmp = num;

                //convert binary -> decimal
                while (tmp)
                { //while still divisible by 10
                    int last = tmp % 10;
                    tmp /= 10; //cut off last digit
                    dec_val += last * base;
                    base *= 2;
                }

                //convert values more than 10 to hex form
                if (dec_val > 9)
                {
                    ans += ('a' + static_cast<char>(dec_val - 10));
                }
                else
                {
                    ans += std::to_string(dec_val);
                }
                if (i != 0 && ((i + 1) % 16 == 0))
                {
                    ans += ":";
                } //every 16 bits, print a colon to conform with IPv6 styling syntax

                currentStr = ""; //reset current string to get next 4 bits
            }
        }
        ans = ans.substr(0, ans.length() - 1);
        if (ans == "0:0:0:0")
        {
            ans += "\t";
        }
        return ans;
    }

private:
    list<RouterTableEntry> routes; //list of routes for the router

    //operator<<() -- prints all entries in the router table including destination IP, subnet mask, and interface number
    friend ostream &operator<<(ostream &os, const RouterTable &table)
    {
        os << "\nDestination\t\t\t\t\tSubnet Mask\t\tInterface" << endl;
        for (const RouterTable::RouterTableEntry route : table.routes)
        {
            os << route;
        }
        os << "------------------------------------------------------------" << endl;
        return os;
    }

    //prints IP address of input table entry
    friend ostream &operator<<(ostream &os, const RouterTableEntry &route)
    {
        //print out IP address, mask subnet, and interface number
        os << printIP(route.destinationIP.to_string());
        // Print netmask
        os << "\t\t";
        os << route.subnetMask << "\t\t\t"
           << route.interface << endl;

        return os;
    }
};