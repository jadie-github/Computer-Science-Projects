/* Jessica Nguyen
CSS 432, Program 4
switch.h
This class represents a network switch functions: forwarding an ethernet frame; print the current switch table;
print MAC address of a frame; and looking up their corresponding interfaces
*/

#include <iostream>
#include <bitset>
#include "SwitchTable.h"
using namespace std;
class Switch
{
public:
    // struct that will hold an Ethernet frame
    struct ethernetFrame
    {
        // 160 bits in the header
        bitset<64> preamble;
        bitset<48> destAddr;
        bitset<48> sourceAddr;
        bitset<16> length; // length value between 0 to 65534, but cant exceed 1500
        void *payload;     //min 44, max 1500 length
        bitset<4> crc;

        ethernetFrame()
        {
            preamble = bitset<64>(0x267c698e1f692a);
            length = bitset<16>(0xf9);
            payload = static_cast<void *>(new std::string("this is a switch message!"));
            crc = bitset<4>("0110");
        }
    };
    
    //constructor for Switch
    Switch();

    /* forwardEthernetFrame() -- performs the processing and forwarding of a single ethernet frame
    selflearns the incoming frame's MAC address as it receives new frames
    while simultaneously add them into the switch table
    */
    void forwardEthernetFrame(Switch::ethernetFrame input);

    /*printSwitchTable() -- prints every entry in the switch table in terms of their MAC address and interface number
    */  
    void printSwitchTable();

private:
    SwitchTable *switchTable;
    //obtainInterface() -- returns the next interface available to assign to a new incoming ethernet frame, default to 0 for the first frame received
    string obtainInterface();

    /*operator<<() -- prints MAC address of input ethernet frame f
    */
    friend ostream &operator<<(ostream &os, const ethernetFrame &f);
};
