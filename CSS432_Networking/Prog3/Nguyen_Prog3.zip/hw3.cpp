/* Jessica Nguyen
CSS 432, Program 3
hw3.cpp
This program uses UDP (User Datagram Protocol) --  a connectionless, unreliable transport layer protocol 
which does not prevent loss or or re-ordering of messages, to implement the stop-and-wait and 
sliding window algorithms and evaluate their performance in transferring 20,000 packets over the 
1Gbps network in the Linux Remote Lab
*/

#include <iostream>
#include <random>
#include <sys/types.h>  // socket, bind
#include <sys/socket.h> // socket, bind, listen, inet_ntoa
#include <netinet/in.h> // htonl, htons, inet_ntoa
#include <arpa/inet.h>  // inet_ntoa
#include <netdb.h>      // gethostbyname
#include <unistd.h>     // read, write, close
#include <strings.h>    // bzero
#include <sys/poll.h>   // poll( )
#include <sys/uio.h>    // writev
#include <sys/time.h>   //gettimeofday
#include <stdio.h>
#include <errno.h>
#include <fcntl.h>
#include <string>
#include <signal.h>
#include "Timer.h"

//constants
#define MAX 20000 //testing
#define PORT_NUM 1089
#define BUFFER_SIZE 1460      //1 int = 4 bytes, 1460 bytes = 365 ints
#define TIMEOUT_DURATION 1500 //microseconds
#define NULL_SD -1            // means no sd descriptor
#define MAX_DROP_RATE 10

//global variables
int port;                    // this UDP port
int sd;                      // this UDP sd descriptor
struct sockaddr_in myAddr;   // my sd address for internet
struct sockaddr_in destAddr; // a destination sd address for internet
struct sockaddr srcAddr;     // a source sd address for internet

//forward declarations
void serverConnect(int); // open an UDP sd with int port
void close();
bool connectToHost(char[]); // set the IP addr given an IP name in char[]
int pollData();             // check if this sd has data to receive
int sendTo(char[], int);    // send a message in char[] whose size is int
int recvFrom(char[], int);  // receive a message in char[] of int size
int sendACK(char[], int);   // send an ack message in char[] of int size
void signal_callback_handler(int);
void clientUnreliable(const int, const int, int[]);
void serverUnreliable(const int, const int, int[]);
int clientStopWait(const int, const int, int[]);
void serverReliable(const int, const int, int[]);
int clientSlidingWindow(const int, const int, int[], int);
void serverEarlyRetrans(const int, const int, int[], int, int);
void test4Client(int[], int);
void test4Server(int[], int);

int main(int argc, char *argv[])
{
    if (argc != 1 && argc != 2)
    {
        cerr << "Error: Must pass in either hostname for client program, or no parameters for server program." << std::endl;
        return -1;
    }
    signal(SIGINT, signal_callback_handler);
    int message[BUFFER_SIZE / 4]; // 1 int = 4 bytes, 1460 bytes = 365 ints
    serverConnect(PORT_NUM);      //initiate sd server side

    //both sides show:
    int window_size;
    std::cout << "Choose a window size -->";
    std::cin >> window_size;

    int testCase;
    std::cout << "Choose a testcase" << std::endl;
    std::cout << "   1: unreliable test" << std::endl;
    std::cout << "   2: stop-and-wait test" << std::endl;
    std::cout << "   3: sliding window" << std::endl;
    std::cout << "   4: sliding window with errors" << std::endl;
    std::cout << "-->";
    std::cin >> testCase;

    if (argc == 2)
    {
        //1 param for hostname ==> client side
        if (!connectToHost(argv[1])) //initiate sd client side
        {
            return -1;
        }

        Timer timer;
        int retransmitted = 0;

        switch (testCase)
        {
        case 1:
            std::cout << "Starting unreliable connection..." << std::endl;
            timer.start();
            clientUnreliable(sd, MAX, message);

            std::cout << "Finished unreliable connection, elapsed time = " << timer.stop() << " usec"
                      << "\n"
                      << std::endl;
            break;
        case 2:
            std::cout << "Starting stop-and-wait connection..." << std::endl;

            timer.start();
            retransmitted = clientStopWait(sd, MAX, message);

            std::cout << "Finished stop-and-wait connection, elapsed time = " << timer.stop() << " usec" << std::endl;
            std::cout << "Number of retransmitted messages = " << retransmitted << "\n"
                      << std::endl;
            break;
        case 3:
            std::cout << "Starting sliding window connection..." << std::endl;
            //increment the window size by 1 each time
            for (int windowSize = 1; windowSize <= window_size; windowSize++)
            {
                std::cout << "Window size = " << windowSize << std::endl;
                timer.start();
                retransmitted = clientSlidingWindow(sd, MAX, message, windowSize);

                std::cout << "Elapsed time = " << timer.stop() << " usec" << std::endl;
                std::cout << "Number of retransmitted messages = " << retransmitted << std::endl;
            }
            std::cout << "Finished sliding window connection\n"
                      << std::endl;
            break;
        case 4:
            std::cout << "Starting sliding window connection with errors..." << std::endl;

            for (int droprate = 0; droprate <= MAX_DROP_RATE; droprate++) //run all percents drop rate
            {
                for (int windowSize = 1; windowSize <= window_size; windowSize++) //run all window sizes
                {
                    std::cout << "Window size = " << windowSize << std::endl;
                    timer.start();
                    retransmitted = clientSlidingWindow(sd, MAX, message, windowSize);

                    std::cout << "Elapsed time = " << timer.stop() << " usec" << std::endl;
                    std::cout << "Number of retransmitted messages = " << retransmitted << std::endl;
                    usleep(10); //dont run the next client too fast in case server hadn't close yet
                }
            }
            std::cout << "Finished sliding window connection with errors" << std::endl;
            break;
        default:
            cerr << "Error: Please only input from 1 -> 4 for options" << std::endl;
            return -1;
        }
    }
    else
    {
        // no params ==> server side
        switch (testCase)
        {
        case 1:
            serverUnreliable(sd, MAX, message);
            std::cout << "Exiting switch" << std::endl;
            break;
        case 2:

            serverReliable(sd, MAX, message);

            break;
        case 3:
            for (int windowSize = 1; windowSize <= window_size; windowSize++)
            {
                serverEarlyRetrans(sd, MAX, message, windowSize, 0); // 0 drop rate, always sends ACK
            }
            break;
        case 4:
        
            for (int droprate = 0; droprate <= MAX_DROP_RATE; droprate++)
            {
                for (int windowSize = 1; windowSize <= window_size; windowSize++) //run all window sizes

                {
                    serverEarlyRetrans(sd, MAX, message, windowSize, droprate); 
                    usleep(10);
                }
            }
            
            break;
        default:
            std::cerr << "Error: Please only input from 1 -> 4 for options" << std::endl;
            return -1;
        }

        std::cout << "Server ending..." << std::endl;
        for (int i = 0; i < 10; i++)
        {
            sleep(1);
            int ack = MAX - 1;
            sendACK((char *)&ack, sizeof(ack));
        }
    }
    return 0;
}

//connects the server side to the socket
void serverConnect(int inputport)
{

    port = inputport;
    sd = NULL_SD;

    // Open a UDP sd (a datagram sd )
    if ((sd = socket(AF_INET, SOCK_DGRAM, 0)) < 0)
    {
        cerr << "Cannot open a UDP " << std::endl;
    }

    // Bind our local address
    bzero((char *)&myAddr, sizeof(myAddr));     // Zero-initialize myAddr
    myAddr.sin_family = AF_INET;                // Use address family internet
    myAddr.sin_addr.s_addr = htonl(INADDR_ANY); // Receive from any addresses
    myAddr.sin_port = htons(port);              // Set my sd port

    int bindres = ::bind(sd, (sockaddr *)&myAddr, sizeof(myAddr));
    if (bindres < 0)
    {
        cerr << "Cannot bind the local address to the UDP " << std::endl;
    }
}

// closes the open socket after running algorithms
void close()
{
    // Close the sd being used
    if (sd != NULL_SD)
        close(sd);
}

// Set the IP addr given a destination IP name in char[] 
bool connectToHost(char ipName[])
{

    // Get the host entry corresponding to this destination ipName
    struct hostent *host = gethostbyname(ipName);
    if (host == NULL)
    {
        cerr << "Cannot find hostname." << std::endl;
        return false; // set in failure
    }

    // Fill in the structure "sendSockAddr" with this destination host entry
    bzero((char *)&destAddr, sizeof(destAddr)); // zero-initialize
    destAddr.sin_family = AF_INET;              // Use address family internet
    destAddr.sin_addr.s_addr =                  // set the destination IP addr
        inet_addr(inet_ntoa(*(struct in_addr *)*host->h_addr_list));
    destAddr.sin_port = htons(port); // set the destination port

    return true; // set in success
}

// Check if this sd has data to receive 
//returns 1 if yes, 0 or less if none
int pollData()
{
    struct pollfd pfd[1];
    pfd[0].fd = sd;             // declare I'll check the data availability of sd
    pfd[0].events = POLLRDNORM; // declare I'm interested in only reading from sd

    // check it immediately and return a positive number if sd is readable,
    // otherwise return 0 or a negative number
    return poll(pfd, 1, 0);
}

// Send msg[] of length size through the sd sd 
int sendTo(char msg[], int length)
{

    // return the number of bytes sent
    return sendto(sd, msg, length, 0, (sockaddr *)&destAddr, sizeof(destAddr));
}

// Receive data through the sd sd and store it in msg[] of lenth size
int recvFrom(char msg[], int length)
{

    // zero-initialize the srcAddr structure so that it can be filled out with
    // the address of the source computer that has sent msg[]
    socklen_t addrlen = sizeof(srcAddr);
    bzero((char *)&srcAddr, sizeof(srcAddr));

    // return the number of bytes received
    return recvfrom(sd, msg, length, 0, &srcAddr, &addrlen);
}

// Send through the sd sd an acknowledgment in msg[] whose size is length 
int sendACK(char msg[], int length)
{

    // assume that srcAddress has be filled out upon the previous recvFrom( )
    // method.

    // return the number of bytes sent
    return sendto(sd, msg, length, 0, &srcAddr, sizeof(srcAddr));
}

//TEST 1 Client
/* clientUnreliable() -- send 20000 packets to server without needing ACKs
*/
void clientUnreliable(const int sock, const int max, int message[])
{
    std::cout << "Calling unreliable client" << std::endl;
    //sends 20000 times
    for (int i = 0; i < max; i++)
    {
        message[0] = i;
        std::cout << "Sending message " << i << std::endl; //denotes sequence number by labeling the first slot
        sendTo((char *)message, BUFFER_SIZE);              //send buffer
    }
}

//TEST 1 Server
/* serverUnreliable() -- receives 20000 packets from client, doesn't send back ACKs
*/
void serverUnreliable(const int sock, const int max, int message[])
{
    std::cout << "Calling unreliable server" << std::endl;

    for (int i = 0; i < max; i++)
    {
        recvFrom((char *)message, BUFFER_SIZE);
        std::cout << "Got a message from client number " << message[0] << std::endl;
    }
    std::cout << "Returning from loop" << std::endl;
}

//TEST 2 Client
/* clientStopWait() - sends 20000 packets 1 by 1, will wait for an ACK from client before moving on
*/
int clientStopWait(const int sock, const int max, int message[])
{
    std::cout << "Calling stop and wait client" << std::endl;
    int ans = 0;
    Timer timer;

    for (int i = 0; i < max; i++)
    {
        message[0] = i; //denotes sequence number by labeling the first slot
        std::cout << "Sending message " << i << std::endl;
        sendTo((char *)message, BUFFER_SIZE);

        timer.start();
        bool sent = false;

        while (timer.stop() <= TIMEOUT_DURATION) //as long as not timeout yet
        {                                        // wait until there's data back from the server by calling poll()
            if (pollData() > 0)
            {
                int buffer[BUFFER_SIZE / 4];
                recvFrom((char *)buffer, BUFFER_SIZE); //read back data from server
                std::cout << "ACK Number received: " << buffer[0] << std::endl;
                if (buffer[0] == i)
                {
                    //if in order
                    sent = true;
                    break;
                }
            }
        }

        //timeout, have to resend
        if (!sent)
        {
            std::cout << "Timeout: retransmitting message number " << i << std::endl;
            ans++; //count the number of retransmitted messages
            i--;   //has to resend the last packet so decrease i to step one back
        }
    }

    return ans;
}

//TEST 2 Server
/* serverReliable() -- receives 20000 packets from client, will send back ACK once it receives
*/
void serverReliable(const int sock, const int max, int message[])
{
    std::cout << "Calling stop and wait server" << std::endl;
    Timer timer;
    for (int i = 0; i < max;)
    {
        recvFrom((char *)message, BUFFER_SIZE);
        std::cout << "Received a message from client number " << message[0] << std::endl;

        if (message[0] == i)
        {
            //right order
            int buffer[BUFFER_SIZE / 4];
            buffer[0] = i;
            std::cout << "Sending ACK number " << i << std::endl;
            sendACK((char *)buffer, BUFFER_SIZE);
            i++;
        }
        else
        {
            //packet not in right order, need to resend previous
            int buffer[BUFFER_SIZE / 4];
            buffer[0] = i - 1;
            std::cout << "Wrong order, retransmitting ACK number " << (i - 1) << std::endl;
            sendACK((char *)buffer, BUFFER_SIZE);
        }
    }
}

//TEST 3, 4 Client
/* clientSlidingWindow() -- sends 20000 packets to server up to a certain window size, then 
waits for the server to confirm ACK, then moves the sliding window forward once it gets ACK
*/
int clientSlidingWindow(const int sock, const int max, int message[], int windowSize)
{
    std::cout << "Calling sliding window client for window size " << windowSize << std::endl;

    int ans = 0, ackNum = 0, next = 0;

    //keep sending packets until hit max
    for (int cur = 0; cur < max || next < max;)
    {
        //in between window
        if (next + windowSize > cur && cur < max)
        {
            message[0] = cur;
            std::cout << "Sending to server message = " << cur << std::endl;
            sendTo((char *)message, BUFFER_SIZE);

            //delay to not read instantly
            usleep(1);
            if (pollData() > 0)
            {
                int ackRec[BUFFER_SIZE / 4];
                recvFrom((char *)ackRec, BUFFER_SIZE); //receive ACK from server side

                ackNum = ackRec[0];
                std::cout << "ACK Number received:  " << ackNum << std::endl;
                if (ackNum == next) //if in the correct expected order, move next up
                {
                    next++;
                }
                else
                {
                    std::cout << "Duplicated packet " << ackNum << " received" << std::endl;
                }
            }
            cur++;
        }
        else //if not in the window
        {
            Timer time;
            time.start(); //start timer
            bool timeout = false;
            while (pollData() <= 0)
            {
                //Times out
                if (time.stop() >= TIMEOUT_DURATION)
                {
                    timeout = true;
                    break;
                }
            }

            //Has to retransmit
            if (timeout)
            {
                std::cout << "Timeout: retransmitting from message " << cur << std::endl;
                ans++;
                cur--;
            }
            else
            {
                //Found an ack
                int ackRec[BUFFER_SIZE / 4];
                recvFrom((char *)ackRec, BUFFER_SIZE);
                ackNum = ackRec[0];
                if (ackNum >= next) //ack back from server, updates sliding window
                {
                    next = ackNum + 1;
                }
                else
                {
                    //not the ack we wanted

                    std::cout << "Duplicated packet " << ackNum << " received" << std::endl;

                    ans++;
                    cur = next; //retransmit lowest ACKed packet
                }
            }
        }
    }
    return ans;
}

//TEST 3, 4 Server
/* serverEarlyRetrans() -- receives 20000 packets from client, will save packet recieved into 
local buffer, then send selective ACK to client
*/
void serverEarlyRetrans(const int sock, const int max, int message[], int windowSize, int dropRate)
{
    std::cout << "Calling sliding window server for window size " << windowSize << std::endl;
    std::cout << "drop rate is " << dropRate << std::endl;

    int expected = 0, ack = 0;
    bool array[max];
    //repopulates the array with falses.
    for (int j = 0; j < max; j++)
    {
        array[j] = false;
    }

    //while we have not gotten all packets
    while (expected < max)
    {
        recvFrom((char *)message, BUFFER_SIZE);
        //Expected to receive
        if (message[0] == expected)
        {
            array[expected] = true;
            for (int i = 0; i < max; i++)
            {
                if (array[i] == true)
                {
                    expected = i + 1; //find biggest expected
                }
            }
        }
        else
        {
            //not expected but still take
            array[message[0]] = true;
        }
        random_device rd;                             //Will be used to obtain a seed for the random number engine
        mt19937 gen(rd());                            //Standard mersenne_twister_engine seeded with rd()
        uniform_int_distribution<> randomInt(0, 100); // set up the range

        int random = randomInt(gen);
        if (random < dropRate) //for test 4: drop packets by not sending ACK
        {
            std::cout << "Dropping packet " << (expected - 1) << std::endl;
            continue;
        }

        int ackSend[BUFFER_SIZE / 4];
        ackSend[0] = (expected - 1);
        std::cout << "Sending ACK = " << ackSend[0] << std::endl;
        sendACK((char *)ackSend, BUFFER_SIZE);
    }
}

//handles ctrl-C exits from command line
void signal_callback_handler(int signum)
{
    std::cout << "Caught signal " << signum << std::endl;
    // Terminate program
    exit(signum);
}
