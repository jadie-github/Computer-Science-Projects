/* Jessica Nguyen
CSS 432, Program 3
Timer.h
This class is a Timer object to register the start and stop times of the test cases for the UDP class
*/
#include <sys/time.h>
#include <iostream>
using namespace std;

class Timer
{
public:
    //constructor
    Timer();
    //other methods?
    void start();
    long stop();
private:
    struct timeval startTime;
    struct timeval endTime;
};