/* Jessica Nguyen
CSS 432, Program 3
Timer.cpp
This class is a Timer object to register the start and stop times of the test cases for the UDP class
*/
#include "Timer.h"
#include <sys/time.h>
#include <iostream>
using namespace std;

Timer::Timer()
{
    startTime.tv_sec = 0;
    startTime.tv_usec = 0;
    endTime.tv_sec = 0;
    endTime.tv_usec = 0;
}
//other methods?
void Timer::start()
{
    gettimeofday(&startTime, nullptr);
}
long Timer::stop()
{
    gettimeofday(&endTime, nullptr);
    return (endTime.tv_sec - startTime.tv_sec) * 1000000 + (endTime.tv_usec - startTime.tv_usec); //convert to microseconds unit
}

